import { NestedTreeControl } from '@angular/cdk/tree';
import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { MatTreeNestedDataSource } from '@angular/material/tree';

/*Import for actions/effects/reducers to be used in the component.*/
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';

/*Angular material Imports*/
import { MatDialog } from '@angular/material/dialog';
import { MatSidenav, MatSidenavContent } from '@angular/material/sidenav';

import * as fromStore from '@app/global-store';

/* service calls */
import { PlantService } from '@app/services/plant.service';
import { AssetData, ILicenseSubscription, SubDeviceType } from '@appShared/models/common.model';
/* Utility imports */
import _ from 'lodash';
import { UtilityService } from '@app/shared/utility.service';
import {
  subscribedModule,
  defaultImage,
  AssetDetailsTabs,
  allAssetsActiveInactive,
  addPanelSetting,
  HARD_CODE_HIERARCHY_SITE_ID,
} from '@app/shared/constant/app.constant';
import { AssetpageService } from '@appServices/assetpage.service';
import { LocationObject } from '@app/shared/models/common.model';
import { DataSource, ConnectivityParam, PanelList } from '@appModules/assetpage/assets-site-trees/assets-site-trees.model';
import { PlantDetailModel } from '@app/shared/models/plant-list.model';
import { HierarchyService } from '@app/services/hierarchy.service';
import { DynamicPanelDialogComponent } from './dynamic-panel-dialog/dynamic-panel-dialog.component';
import { ConfirmDeleteDialogComponent } from '@app/components/confirm-delete-dialog/confirm-delete-dialog.component';
// import { DashboardOutletDirective } from './dashboard-outlet.directive';
import { TabsComponent } from '@appComponents/dynamic-tabs/tabs/tabs.component';
import { TranslateService } from '@ngx-translate/core';
import { DashboardService } from '@app/services/dashboard.service';
import { subDeviceType, DEFAULT_CONFIRM_DIALOG_CFG, HEALTH_TYPE_MAP } from '@app/shared/constant/app.constant';
import { environment } from 'environments/environment';

/**
 * @title Tree with nested nodes MAT TREE for site hierarchy screen.
 */
@Component({
  selector: 'elcp-assets-site-trees',
  templateUrl: './assets-site-trees.component.html',
  styleUrls: ['./assets-site-trees.component.scss'],
})
export class AssetsSiteTreesComponent implements OnInit, OnDestroy {
  treeControl = new NestedTreeControl<any>((node) => node.children);
  dataSource = new MatTreeNestedDataSource<any>();
  @ViewChild('sidenav', { static: false }) sidenav: MatSidenav;
  @ViewChild('myDiv', { static: false }) divView: MatSidenavContent;
  @ViewChild(TabsComponent, { static: false }) tabsComponent: TabsComponent; // This is used for getting the reference of Tabs component

  location: LocationObject; // This is contain the plant location details
  plantSubName: string; // This is contain the plant name
  plantId: string; // Variable to hold the plant Id
  plantType: string; // Variable to hold the plant type
  plantRole: string; // Variable to hold the plant Role
  subscription: Subscription[] = []; // Creating subscription for destroying the binding with service.
  loadingFlag: boolean; // Variable the loading indictor
  panelLoadingFlag = false; // Variable the loading indictor
  plantName: string; // Variable to hold the plant name
  redirectTab: string;
  selectedPlant: PlantDetailModel; // Variable to hold the selected plant
  assetDetails;
  defaultDeviceImage: string = defaultImage.Device; // default plant image for device.
  defaultPlantImage: string = defaultImage.Plant; // default plant image for device. defaultImage.Plant
  display = false;
  dragDisabled = true;
  /* Below declaration to identify the selection to open the asset tab */
  overview: string = AssetDetailsTabs.OVERVIEW;
  overviewMRC: string = AssetDetailsTabs.OVERVIEW_MRC;
  events: string = AssetDetailsTabs.EVENTS;
  service: string = AssetDetailsTabs.SERVICE;
  alertCondition: string = AssetDetailsTabs.ALERT_CONDITION;
  connectivity: string = AssetDetailsTabs.CONNECTIVITY;
  documentation: string = AssetDetailsTabs.DOCUMENTATION;
  information: string = AssetDetailsTabs.INFORMATION;
  settings: string = AssetDetailsTabs.SETTINGS;
  assetMaintenance: string = AssetDetailsTabs.MAINTENANCE;
  activeTabId: string;
  rendered: boolean; // this variable is used to check if get panel has already been rendered or not
  /* site tree declaration */
  panelList: Array<PanelList> = [];
  subDeviceType: SubDeviceType = subDeviceType; // Declare the type to display overview show/hide.
  panelTranslation: object;
  /* Below declaration for custom */
  customHierarchyTree = [];
  panelName: string;
  panelId: string;
  hasActiveDashboard: boolean; // Adding to check if it has any active dashboard
  childCount: number;
  disableAddPanelBtn = false; // This button will disable add new panel button.
  siteTranslate;

  HEALTH_TYPE_MAP = HEALTH_TYPE_MAP;
  licenseSubscription: ILicenseSubscription; // Subscription object

  /**
   * Creates an instance of ConnectivityComponent.
   * @param {Store<fromStore.ContainerState>} store // To dispatch action and subscribe to the data from reducer.
   * @param {PlantService} plantService // API calls for plant details
   * @param {UtilityService} utils // utils service for common utility functions which can be reused multiple times.
   * @memberof AssetsSiteTreesComponent
   */
  constructor(
    private store: Store<fromStore.ContainerState>,
    private dashboardService: DashboardService,
    public dialog: MatDialog,
    private utils: UtilityService,
    private hierarchyService: HierarchyService,
    private plantService: PlantService,
    private translateService: TranslateService,
    private assetPageService: AssetpageService
  ) {}
  // This will check the parent node has child.
  // tslint:disable-next-line: no-shadowed-variable
  hasChild = (_: number, node: any) => !!node.children && node.children.length > 0;

  /**
   *
   *
   * @memberof AssetsSiteTreesComponent
   * @description Life cycle hooks
   */
  ngOnInit() {
    /* subscription to the plants */
    this.subscription.push(
      this.plantService.selectedPlantObj$.subscribe((plantDetailResponse) => {
        if (plantDetailResponse) {
          this.selectedPlant = plantDetailResponse;
          this.plantSubName = this.utils.constructPlantSubName(plantDetailResponse);
          this.plantId = plantDetailResponse['id'] ? plantDetailResponse['id'] : null;
          this.plantName = plantDetailResponse['name'] ? plantDetailResponse['name'] : null;
          this.plantRole = plantDetailResponse.plantRole ? plantDetailResponse.plantRole : null;
          this.plantType = plantDetailResponse['plantType'] ? plantDetailResponse['plantType'] : null;
          this.LoadHierarchyPanelList();
          if (_.hasIn(plantDetailResponse, 'id') && _.hasIn(plantDetailResponse, 'licenseSubscription')) {
            let licenseSubscribeData = plantDetailResponse['licenseSubscription'];

          // get the subscription details 
          this.licenseSubscription = this.utils.getLicenseSubscription(licenseSubscribeData);
          }
        }
      })
    );

    /* Calling subscribe method to get data from state */
    this.getSiteTreeData();
    this.getCustomPanelList();
    this.getLanguageTranslatedData();
  }

  /**
   *
   *
   * @memberof AssetsSiteTreesComponent
   */
  LoadHierarchyPanelList() {
    this.rendered = false;
    this.store.dispatch(new fromStore.LoadHierarchyPanelList(this.plantId, this.plantType, 'custom'));
  }

  /**
   *
   *
   * @memberof AssetsSiteTreesComponent
   * @description Below method is get the translate value.
   */
  getLanguageTranslatedData() {
    this.translateService.get('customPanel').subscribe((text: JSON) => {
      this.panelTranslation = text;
    });
    this.translateService.get('Site.Site').subscribe((site: any) => {
      this.siteTranslate = site;
    });
  }

  /**
   *
   *
   * @param {Array<any>} siteTree
   * @memberof AssetsSiteTreesComponent
   * @description This will construct the site name for first
   */
  constructSubName(siteTree: Array<any>) {
    if (_.size(siteTree) > 0 && _.hasIn(siteTree[0], 'subName')) {
      const subName = this.utils.constructPlantSubName(this.selectedPlant);
      siteTree[0].subName = subName;
      return siteTree;
    }
  }

  /**
   *
   *
   * @param {string} dialogType
   * @memberof AssetsSiteTreesComponent
   */
  openPanelDialog(dialogType: string) {
    const dialogRef = this.dialog.open(DynamicPanelDialogComponent, {
      width: '600px',
      height: '55%',
      minHeight: '210px',
      data: {
        dialogType,
        plantId: this.plantId,
        panelName: this.panelName,
        selectedPanelId: this.panelId,
        plantName: this.plantName,
        plantSubName: this.plantSubName,
        plantType: this.plantType,
      },
      panelClass: 'my-dialog-container-class',
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result && _.hasIn(result, 'status')) {
        this.loadingFlag = true;
        this.LoadHierarchyPanelList();
        if (result.customTreeNode && result.customTreeNode !== null) {
          const customHierarchyTree = result.customTreeNode;
          this.customHierarchyTree = [...customHierarchyTree];
        }
      }
    });
  }

  // /**
  //  *
  //  *
  //  * @param {ConnectivityParam} $event
  //  * @memberof AssetsSiteTreesComponent
  //  * @description To pass to the asset details component.
  //  */
  // getAssetId($event: ConnectivityParam) {
  //   this.redirectTab = $event.pageDetails;
  //   this.assetDetails = this.utils.constructAssetObj($event.asset);
  //   this.sidenav.open();
  // }

  /**
   *
   * @param tab
   * Event to delete the dashboard
   * Update the deleted status to server
   * Load the dashboard again
   */
  deletePanel() {
    const dialogRef = this.dialog.open(ConfirmDeleteDialogComponent, {
      ...DEFAULT_CONFIRM_DIALOG_CFG,
      data: {
        Title: this.panelTranslation['deletePanel'],
        subTitle: this.panelTranslation['confirmAction'],
        buttonText: this.panelTranslation['delete'],
        displayCancelButton: true,
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.loadingFlag = true;
        this.hierarchyService.deleteCustomPanel(this.plantId, this.plantType, this.panelId).subscribe(
          (resObj) => {
            // this.loadingFlag will set false after request done (avoid ExpressionChangedAfterItHasBeenCheckedError).
            // path: getCustomPanelList ---> tabsComponent.ngOnInit ---> tabChangeHandler ---> hierarchyService.getCustomTreeByPanelId
            this.LoadHierarchyPanelList();
          },
          (err) => {
            this.utils.openSnackBar(this.utils.formatErrorMsg(err), 'danger');
            this.loadingFlag = false;
          }
        );
      }
    });
  }

  /**
   *
   *
   * @param {number} previousIndex
   * @param {number} currentIndex
   * @returns
   * @memberof AssetsSiteTreesComponent
   */
  updatePanelOrder(previousIndex: number, currentIndex: number) {
    const targetPanelId = this.getId(currentIndex);
    const sourcePanelId = this.getId(previousIndex);
    const direction = previousIndex < currentIndex ? 'DOWN' : 'UP';
    if (!targetPanelId || !sourcePanelId) {
      return;
    }
    this.loadingFlag = true;
    this.hierarchyService
      .updateCustomPanelOrder(this.plantId, this.plantType, {
        sourcePanelId,
        targetPanelId,
        direction,
      })
      .subscribe(
        (res) => {
          // this.loadingFlag will set false after request done (avoid ExpressionChangedAfterItHasBeenCheckedError).
          // path: getCustomPanelList ---> tabsComponent.ngOnInit ---> tabChangeHandler ---> hierarchyService.getCustomTreeByPanelId
          this.LoadHierarchyPanelList();
        },
        (err) => {
          this.utils.openSnackBar(this.utils.formatErrorMsg(err), 'danger');
          this.loadingFlag = false;
        }
      );
  }

  /**
   *
   *
   * @private
   * @param {number} index
   * @returns
   * @memberof AssetsSiteTreesComponent
   * @description This method is used by updatePanelOrder for getting the id from index
   */
  private getId(index: number) {
    const panelObject = this.panelList[index];
    const id = panelObject['id'];
    return id;
  }

  /**
   *
   *
   * @memberof AssetsSiteTreesComponent
   * @description update last view panel
   */
  updateLastViewed(panelId: string | null) {
    this.hierarchyService.updateLastViewed(this.plantId, this.plantType, panelId, { name: this.panelName }).subscribe(
      (response) => {},
      (err) => {}
    );
  }

  /**
   *
   *
   * @memberof AssetsSiteTreesComponent
   * @description On click on specific tab below function will trigger.
   */
  tabChangeHandler($event) {
    if ($event && _.hasIn($event, 'eachTab') && _.hasIn($event.eachTab, 'id') && _.hasIn($event.eachTab, 'title')) {
      this.activeTabId = this.panelId = $event.eachTab.id;
      this.panelName = $event.eachTab.title;

      if ($event.index !== 0) {
        this.updateLastViewed(this.panelId);
        this.loadingFlag = true;
        this.hierarchyService.getCustomTreeByPanelId(this.plantId, this.plantType, this.panelId).subscribe(
          (response) => {
            if (_.hasIn(response, 'value')) {
              this.activeTabId = $event.eachTab.id;
              const nodeDetail = this.utils.getNestedObject(response, ['value', 'nodeDetail']);
              if (nodeDetail !== undefined) {
                let customHierarchyTree = nodeDetail && JSON.parse(nodeDetail);
                customHierarchyTree = this.constructSubName(customHierarchyTree);
                this.customHierarchyTree = [...customHierarchyTree];
              }
            }
            this.loadingFlag = false;
          },
          (err) => {
            this.loadingFlag = false;
          }
        );
      } else {
        this.updateLastViewed(HARD_CODE_HIERARCHY_SITE_ID);
        this.store.dispatch(new fromStore.LoadSiteHierarchy(this.plantId, this.plantType));
      }
    }
  }

  /**
   *
   *
   * @memberof AssetsSiteTreesComponent
   * @description This method will subscription to get connectivity state data.
   */
  getCustomPanelList() {
    this.subscription.push(
      this.store.select<any>(subscribedModule.hierarchy).subscribe((state) => {
        if (state && state.customPanelList.loaded && state.customPanelList.data && !this.rendered) {
          let panels = state.customPanelList.data;
          this.tabsComponent.ngOnInit();
          this.rendered = true;
          if (_.size(state.customPanelList.data) > 0) {
            this.disableAddPanelBtn = _.size(state.customPanelList.data) >= addPanelSetting ? true : false;
            panels = _.orderBy(panels, ['position'], ['desc']);
          }
          const panelsList = this.setLastViewedFlag(panels);
          const lastViewedPanel = _.filter(panelsList, (eachPanel) => {
            if (_.hasIn(eachPanel, 'isLastViewed')) {
              return eachPanel['isLastViewed'];
            } else {
              return [];
            }
          });
          if (_.size(lastViewedPanel) === 1) {
            this.activeTabId = lastViewedPanel[0]['id'];
            this.hasActiveDashboard = (lastViewedPanel[0]['isLastViewed'] || {}) === true ? true : false;
          }
          this.panelList = panelsList;
          setTimeout(() => {
            /* The following code is used for triggering the panelLoadedService to notify that panel has been loaded
          so that the Tabs component gets notification and runs the required method to scroll to the respective panel */
            this.dashboardService.panelLoadedService();
          }, 500);
        }
        this.panelLoadingFlag = state && state.customPanelList.loading;
      })
    );
  }

  setLastViewedFlag(panels) {
    const viewedFlag = _.filter(panels, ['isLastViewed', true]);
    if (_.size(viewedFlag) > 0) {
      const staticPanel = [
        {
          id: '28053dcb-eb26-4bd5-b67a-custom910e45',
          name: this.siteTranslate,
          plantId: this.plantId,
          isLastViewed: false,
        },
      ];
      return _.concat(staticPanel, panels);
    } else if (_.size(viewedFlag) === 0) {
      const staticPanel = [
        {
          id: '28053dcb-eb26-4bd5-b67a-custom910e45',
          name: this.siteTranslate,
          plantId: this.plantId,
          isLastViewed: true,
        },
      ];
      return _.concat(staticPanel, panels);
    }
  }

  /**
   * @memberof AssetsSiteTreesComponent
   * @description This method will subscription to get connectivity state data.
   */
  getSiteTreeData() {
    this.subscription.push(
      this.store.select<any>(subscribedModule.siteHierarchy).subscribe((state) => {
        if (state && state.siteHierarchyData) {
          if (state.siteHierarchyData.data) {
            this.constructHierarchy(state.siteHierarchyData.data);
          }
        }
        this.loadingFlag = state && state.siteHierarchyData.loading;
      })
    );
  }

  /**
   *
   *
   * @param {string} page
   * @param {AssetData} rowData
   * @memberof AssetsSiteTreesComponent
   * @description for re-direction to tab.
   */
  redirect(page: string, rowData: AssetData) {

    if(_.hasIn(rowData, 'isUPSModule') && rowData.isUPSModule) {
        return true;
    }

    let isSideNav = false;
    if (this.plantType === 'EDCS' || this.plantType === 'EL') {
      isSideNav = true;
    }
    else if (_.hasIn(rowData, 'isSubstation')) {
      if (rowData.isSubstation === false) {
        isSideNav = true;
      }
    }
    if (isSideNav === true) {
      this.redirectTab = page === 'common' ? this.utils.displayOverviewPage(rowData) : page;
      this.utils.setTab(this.redirectTab);
      const deviceType = _.hasIn(rowData, 'deviceType') ? rowData.deviceType : '';
      const assetId = _.hasIn(rowData, 'id') ? rowData.id : '';
      this.subscription.push(
        this.assetPageService.getAssetDetails(this.plantId, this.plantType, assetId, deviceType).subscribe(
        (response) => {
          if (response['code'] === 'Success') {
            this.assetDetails = response['value'];
            if (!this.assetDetails.id) {
              this.assetDetails.id = assetId;
            }
          } else {
            this.assetDetails = rowData;
          }
        },
        (err) => {
          this.assetDetails = rowData;
        }
      )
    );
      document.body.style.overflowY = 'hidden';
      this.sidenav.open(); 
      this.utils.scrollToTop(); // This will scroll top of the page
    }
  }

  /**
   *
   *
   * @param {ConnectivityParam} $event
   * @memberof ConnectivityComponent
   * @description To pass to the asset details component.
   */
  getAssetId($event: ConnectivityParam) { 
    this.redirectTab = $event.pageDetails;
    const deviceType = _.hasIn($event.asset, 'deviceType') ? $event.asset['deviceType'] : '';
    const assetId = _.hasIn($event.asset, 'Id') ? $event.asset['Id'] : '';
    this.subscription.push(
      this.assetPageService.getAssetDetails(this.plantId, this.plantType, assetId, deviceType).subscribe(
        (response) => {
          if (response['code'] === 'Success') {
            this.assetDetails = response['value'];
            if (!this.assetDetails.id) {
              this.assetDetails.id = assetId;
            }
          } else {
            this.assetDetails = _.hasIn($event.asset, 'assetList') ? $event.asset['assetList'] : {};
          }
        },
        (err) => {
          this.assetDetails = _.hasIn($event.asset, 'assetList') ? $event.asset['assetList'] : {};
          
        }
      )
    );
    document.body.style.overflowY = 'hidden';
    this.sidenav.open();
    this.utils.scrollToTop(); // This will scroll top of the page
  }

  /**
   *
   * @memberof AssetsSiteTreesComponent
   * @description Below method will close the asset setting dialog
   */
  close() {
    this.divView.getElementRef().nativeElement.ownerDocument.body.style.position = '';
    this.divView.getElementRef().nativeElement.ownerDocument.body.style.overflow = 'auto';
    this.sidenav.close();
  }

  updatedNodeList(nodeList: any) {
    this.loadingFlag = true;
    this.hierarchyService.updateCustomTree(this.plantId, this.panelId, this.plantType, nodeList).subscribe(
      (resObj) => {
        this.loadingFlag = false;
      },
      (err) => {
        this.loadingFlag = false;
      }
    );
  }

  /** @description This will construct the structure to display branching lines */
  constructTree(treeData: Array<any>, key: string) {
    const totalSize = _.size(treeData);
    _.forEach(treeData, (value, loopKey) => {
      if(_.hasIn(value, 'deviceTypeCode') && value.deviceTypeCode){
        value.url = environment.deviceImageUrl + this.utils.getDeviceImage(value.deviceTypeCode) + '.jpg';
      }
      if (_.hasIn(value, key)) {
        value.children = [...value[key]];
        value.hideThreeDot = true;
        this.constructTree(value.children, key);
      }
      if (totalSize - 1 === loopKey) {
        value.lastNode = true;
      }
    });
    return treeData;
  }

  /**
   *
   * @param {*} treeData
   * @memberof ConnectivityComponent
   * @description Below method will construct the hierarch tree to pass input as proper format.
   */
  constructHierarchy(treeData: DataSource) {
    /* For EDCS and MRC we will get different key, so added below condition */
    let treeInfo = [];
    if (_.hasIn(treeData, 'energyEquipmentTree') && _.size(treeData.energyEquipmentTree.energyEquipmentTreeInfo) > 0) {
      this.childCount = _.size(treeData.energyEquipmentTree.energyEquipmentTreeInfo);
      treeInfo = [...treeData.energyEquipmentTree.energyEquipmentTreeInfo];
      treeInfo = this.constructTree(treeInfo, 'energyEquipmentTree');
    } else if (_.hasIn(treeData, 'assetEquipmentTree') && _.size(treeData.assetEquipmentTree.assetEquipmentTreeInfo) > 0) {
      this.childCount = _.size(treeData.assetEquipmentTree.assetEquipmentTreeInfo);
      treeInfo = [...treeData.assetEquipmentTree.assetEquipmentTreeInfo];
      treeInfo = this.constructTree(treeInfo, 'assetEquipmentChildTreeInfo');
    }

    const TREE_DATA = [
      {
        name: this.plantName,
        serialNumber: this.plantSubName,
        url: defaultImage.Plant,
        fontIcon: 'building',
        children: treeInfo,
      },
    ];
    this.dataSource.data = TREE_DATA;
    this.treeControl.dataNodes = TREE_DATA;
    this.treeControl.expandAll();
  }

  /**
   *
   * @param {AssetData} selectedAsset
   * @memberof AssetsSiteTreesComponent
   * @description To enable or disable asset
   */
  disableEnableAsset(selectedAsset: AssetData, treeType?: string) {
    if (_.hasIn(selectedAsset, 'deviceStatus') && selectedAsset.deviceStatus === 'Active') {
      this.enableDisableAPICallFunction(selectedAsset, allAssetsActiveInactive.inActive, treeType);
    } else if (_.hasIn(selectedAsset, 'deviceStatus') && selectedAsset.deviceStatus === 'Inactive') {
      this.enableDisableAPICallFunction(selectedAsset, allAssetsActiveInactive.active, treeType);
    } else {
      this.enableDisableAPICallFunction(selectedAsset, allAssetsActiveInactive.inActive, treeType);
    }
  }

  /**
   *
   * @param {*} event
   * @memberof AssetsSiteTreesComponent
   * @description Function called when enable disable site tree is clicked
   */
  customEnableDisableAsset(event: any) {
    this.disableEnableAsset(event.asset, 'custom');
  }

  /**
   *
   * @memberof AssetsSiteTreesComponent
   * @description To reload the site tree after the enable disable asset
   */
  reloadCustomTree() {
    this.loadingFlag = true;
    this.hierarchyService.getCustomTreeByPanelId(this.plantId, this.plantType, this.panelId).subscribe(
      (response) => {
        if (_.hasIn(response, 'value')) {
          const nodeDetail = this.utils.getNestedObject(response, ['value', 'nodeDetail']);
          if (nodeDetail !== undefined) {
            let customHierarchyTree = nodeDetail && JSON.parse(nodeDetail);
            customHierarchyTree = this.constructSubName(customHierarchyTree);
            this.customHierarchyTree = [...customHierarchyTree];
          }
        }
        this.loadingFlag = false;
      },
      (err) => {
        this.loadingFlag = false;
      }
    );
  }

  /**
   *
   * @param {AssetData} selectedAsset
   * @param {string} deviceStatus
   * @memberof AllAssetsComponent
   * @description to make an API call for disable asset
   */
  enableDisableAPICallFunction(selectedAsset: AssetData, deviceStatus: string, treeType?: string) {
    const payload = {};
    this.subscription.push(
      this.assetPageService.enableDisableAsset(this.plantId, selectedAsset.plantType, selectedAsset.id, deviceStatus, payload).subscribe(
        (data) => {
          if (treeType) {
            this.store.dispatch(new fromStore.LoadSiteHierarchy(this.plantId, this.plantType));
            this.reloadCustomTree();
          } else {
            this.store.dispatch(new fromStore.LoadSiteHierarchy(this.plantId, this.plantType));
          }
        },
        (error) => {}
      )
    );
  }

  /**
   *
   *
   * @memberof AssetsSiteTreesComponent
   * @description  Destroying all Subscription for this component.
   */
  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.subscription.forEach((sub) => {
      if (sub) {
        sub.unsubscribe();
      }
    });
  }
}
