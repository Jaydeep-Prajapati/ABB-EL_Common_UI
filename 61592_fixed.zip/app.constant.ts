/*Subscribed module*/
export const subscribedModule = {
    dashboard: 'dashboard',
    widgets: 'widgets',
    allAsset: 'allAsset',
    energyMonitor: 'energyMonitor',
    peakMonitor: 'peakMonitor',
    groupPeakMonitor: 'groupPeakMonitor',
    analogDataMonitor: 'analogDataMonitor',
    digitalDataMonitor: 'digitalDataMonitor',
    powerDemand: 'powerDemand',
    powerGeneration: 'powerGeneration',
    energyMixGroup: 'energyMixGroup',
    healthOverview: 'healthOverview',
    eventOverview: 'eventOverview',
    serviceActivityOverview: 'serviceActivityOverview',
    connectivityOverview: 'connectivityOverview',
    addWidgetMenu: 'addWidgetMenu',
    widgetCategory: 'widgetCategory',
    serviceActivities: 'serviceActivities',
    healthByAge: 'healthByAge',
    eventTrend: 'eventTrend',
    latestEvent: 'latestEvent',
    connectivityTrend: 'connectivityTrend',
    assetList: 'assetList',
    realTimeCurrents: 'realTimeCurrents',
    realTimePower: 'realTimePower',
    realTimeVoltage: 'realTimeVoltage',
    energyCost: 'energyCost',
    powerFactor: 'powerFactor',
    assetDetails: 'assetDetails',
    assetDetailsEvents: 'assetDetailsEvents',
    assetDetailsInformation: 'assetDetailsInformation',
    assetDetailsAlert: 'assetDetailsAlert',
    settingsData: 'settingsData',
    customPanelList: 'customPanelList',
    alertDeviceList: 'alertDeviceList',
    alertDefinitionDropdown: 'alertDefinitionDropdown',
    alertProfiles: 'alertProfiles',
    assetCurrentTrend: 'assetCurrentTrend',
    assetVoltageTrend: 'assetVoltageTrend',
    assetPowerData: 'assetPowerData',
    assetConnectivity: 'assetConnectivity',
    pueTrend: 'pueTrend',
    assetDetailsConnectivity: 'assetDetailsConnectivity',
    enpiMonitoring: 'enpiMonitoring',
    assetDetailsMaintenance: 'assetDetailsMaintenance',
    maintenancePage: 'maintenancePage',
    meteringDataMonitoring: 'meteringDataMonitoring',
    particularAlert: 'particularAlert',
    powerForecasting: 'powerForecasting',
    assetDocumentationData: 'assetDocumentationData',
    EventsPage: 'EventsPage',
    settingsDocumentation: 'settingsDocumentation',
    groupRealTimeVoltage: 'groupRealTimeVoltage',
    // energyAuditSummary: 'energyAuditSummary',
    siteHierarchy: 'siteHierarchy',
    hierarchy: 'hierarchy',
    Localization: 'Localization',
    energyData: 'energyData',
    groupRealTimePower: 'groupRealTimePower',
    realTimeMetering: 'realTimeMetering',
    groupRealTimeMetering: 'groupRealTimeMetering',
    arcGuard: 'arcGuard',
    groupRealTimeCurrents: 'groupRealTimeCurrents',
    energyCostComparison: 'energyCostComparison',
    energyAuditSummary: 'energyAuditSummary',
    pueMonitor: 'pueMonitor',
    upsMonitor: 'upsMonitor',
    performanceIndicator: 'performanceIndicator',
    dataAnalyticsReportType: 'dataAnalyticsReportType',
    stateAndEvents: 'stateAndEvents',
    environmentalDataWidget: 'environmentalDataWidget',
    TotalHistoricEnergyData: 'TotalHistoricEnergyData',
    inputDataCalculation: 'inputDataCalculation',
    truOneParameters: 'truOneParameters',
    transferTime: 'transferTime',
    smsNotification: 'smsNotification',
    scheduleReportType: 'scheduleReportType',
    powerQualityThd: 'powerQualityThd',
    energyDataComparison: 'energyDataComparison',
    historicDataMetering: 'HistoricDataMetering',
    powerQualityVoltage: 'powerQualityVoltage',
    overviewMrc: 'overviewMrc',
    upsRealTimeVoltage: 'upsRealTimeVoltage',
    UPSAlarmPanelStatusData: 'UPSAlarmPanelStatusData',
    UPSEvents: 'UPSEvents',
    UPSAlarmStatus: 'UPSAlarmStatus',
    upsRealTimeCurrents: 'upsRealTimeCurrents',
    upsBatteryStatus: 'upsBatteryStatus',
    upsRealTimePower: 'upsRealTimePower',
    upsLatestAlarm: 'upsLatestAlarm',
    upsPeakMonitor: 'upsPeakMonitor',
    arcGuardCSU2: 'arcGuardCSU2',
    multiPeakMonitor: 'multiPeakMonitor',
    assetEnergyTrend: 'assetEnergyTrend',
    energyCompositionTrend: 'energyCompositionTrend',
    energyCompositionOverview: 'energyCompositionOverview',
    PCSPeakMonitoring: 'PCSPeakMonitoring',
    pcsRealTimeCurrents: 'pcsRealTimeCurrents',
    PCSLogs: 'PCSLogs',
    pcsRealTimePower: 'pcsRealTimePower',
    pcsRealTimeVoltage: 'pcsRealTimeVoltage',
    cmUfd: 'cmUfd',
    PDURealTimeVoltage: 'PDURealTimeVoltage',
    UMC: 'UMC',
    trendsData: 'trendsData',
    WeatherForecast48Hours: 'weatherForecastHourly',
    Frequency:'Frequency',
    CurrentWeather: 'CurrentWeather',
    WeatherForecast: 'weatherForecastDaily',
    ATSSourceStatus: 'ATSSourceStatus',
    AssetPowerFactorTrend: 'AssetPowerFactorTrend'
};

/* Assigning sub device type for overview tab */
export const subDeviceType = {
    EMAX2: 'EMAX2',
    EkipUP: 'EkipUP',
    UPS:'UPS'
};

/* get the dropdown type, Below value will pass in the API */
export const dropdownType = {
    manufacture: 'manufacturers',
    assetClass: 'assetClass',
    widgetGroups: 'widgetGroups',
    equipments: 'equipments',
    inputEquipments: 'inputEquipments',
    getPeriods: 'getperiods',
    getEquipments: 'getEquipments',
    latestEventTypes: 'latesteventtypes',
    trends: 'trends',
    parameter: 'parameter',
    getassetfamilies: 'getassetfamilies',
    upsModules: 'upsmodules'
};
/* event bar chart color code */
export const eventBarChartColor = {
    assetCount: '#2E92FA',
    connectivityCount: '#9EBFF7',
    healthCount: '#B7DAFD',
    ruleCount: '#DDEDFD'
};

/** @enum Used of routing, identifying the page to open tab */
export enum AssetDetailsTabs {
    OVERVIEW = 'overview',
    OVERVIEW_MRC = 'overviewMRC',
    EVENTS = 'events',
    SERVICE = 'service',
    ALERT_CONDITION = 'alertCondition',
    CONNECTIVITY = 'connectivity',
    DOCUMENTATION = 'documentation',
    INFORMATION = 'information',
    SETTINGS = 'settings',
    MAINTENANCE = 'assetMaintenance',
    DATA_ANALYSIS = 'dataAnalysis'
}

/** @enum Used of routing, identifying the page to open tab */
export enum DataAnalysisSubTabs {
    TRENDS = 'trends',
    THERMAL = 'thermal'
}


/* event donut chart color code */
export const eventDonutChartColor = {
    assetCount: '#2E92FA',
    connectivityCount: '#9EBFF7',
    healthCount: '#B7DAFD',
    ruleCount: '#DDEDFD'
};

/* local storage details */
export const localStorageKeyValue = {
    plantDetail: 'plantDetail',
    plantChanged: 'plantChanged'
};

/* widget size declaration */
export const gridWidgetsDynamic = {
    RealTimeCurrents: { cols: 1, rows: 2 },
    UPSRealTimeCurrents: { cols: 1, rows: 2 },
    UPSRealTimeVoltage: { cols: 1, rows: 2 },
    UPSBatteryStatus: { cols: 1, rows: 1},
    RealTimePower: { cols: 1, rows: 2 },
    RealTimeVoltage: { cols: 1, rows: 2 },
    EnergyCost: { cols: 1, rows: 2 },
    PowerFactor: { cols: 1, rows: 1 },
    EnergyMonitoring: { cols: 2, rows: 2 },
    Map: { cols: 1, rows: 1 },
    MultipleSiteLocator: { cols: 2, rows: 2 },
    PeakMonitoring: { cols: 2, rows: 2 },
    GroupPeakMonitoring: { cols: 2, rows: 2 },
    DigitalDataMonitoring: { cols: 2, rows: 2 },
    AnalogDataMonitoring: { cols: 2, rows: 2 },
    HealthOverview: { cols: 1, rows: 1 },
    ServiceActivityOverview: { cols: 1, rows: 1 },
    PowerGeneration: { cols: 1, rows: 1 },
    PowerDemand: { cols: 1, rows: 1 },
    EventOverview: { cols: 1, rows: 1 },
    ConnectivityOverview: { cols: 1, rows: 1 },
    latestEvents: { cols: 1, rows: 2 },
    EventsTrend: { cols: 2, rows: 2 },
    HealthByAge: { cols: 2, rows: 1 },
    ConnectivityTrend: { cols: 2, rows: 2 },
    GroupEnergyMix: { cols: 2, rows: 1 },
    LatestEvents: { cols: 1, rows: 2 },
    AssetList: { cols: 2, rows: 2 },
    ServiceActivities: { cols: 2, rows: 2 },
    LocalTime: { cols: 1, rows: 1 },
    PerformanceMonitoring: { cols: 2, rows: 2 },
    MeteringDataMonitoring: { cols: 2, rows: 2 },
    CurrentTrends: { cols: 2, rows: 2 },
    VoltageTrends: { cols: 2, rows: 2 },
    DevicePowerData: { cols: 2, rows: 2 },
    DataCenterPUE: { cols: 2, rows: 2 },
    PowerForecast: { cols: 2, rows: 2 },
    ARCGuard: { cols: 1, rows: 2 },
    ActiveEnergyAudit: { cols: 1, rows: 2 },
    EnergyData: { cols: 2, rows: 2 },
    EnergyCostComparison: { cols: 1, rows: 2 },
    GroupRealTimeVoltage: { cols: 1, rows: 2 },
    GroupRealTimePower: { cols: 1, rows: 2 },
    RealTimeMetering: { cols: 1, rows: 2 },
    GroupRealTimeMetering: { cols: 1, rows: 2 },
    GroupRealTimeCurrents: { cols: 1, rows: 2 },
    DataCenter: { cols: 2, rows: 1 },
    UPSMonitor: { cols: 2, rows: 2 },
    PerformanceIndicator: { cols: 1, rows: 1 },
    StatesEvents: { cols: 1, rows: 2 },
    EnvironmentalData: { cols: 1, rows: 2 },
    TotalHistoricEnergyData: { cols: 1, rows: 2 },
    UPSAlarmPanelStatusData: { cols: 1, rows: 2 },
    InputDataCalculation: { cols: 1, rows: 1 },
    ATSParameters: { cols: 1, rows: 2 },
    TransferTime: { cols: 2, rows: 2 },
    PowerQuality: { cols: 1, rows: 1 },
    EnergyDataComparison: { cols: 1, rows: 2 },
    HistoricDataMetering: { cols: 1, rows: 2 },
    PowerQualityVoltage: { cols: 1, rows: 1 },
    UPSAlarmStatus: { cols: 1, rows: 2 },
    UPSRealTimePower: { cols: 1, rows: 2 },
    UPSEvents: { cols: 2, rows: 2 },
    UPSAlarm: { cols: 1, rows: 2 },
    UPSPeakMonitoring: { cols: 2, rows: 2 },
    ArcGuardCSU2: { cols: 1, rows: 2},
    MultiPeakMonitoring: { cols: 2, rows: 2 },
    AssetEnergyTrend: { cols: 2, rows: 2 },
    EnergyCompositionTrend: { cols: 2, rows: 2 },
    EnergyCompositionOverview: { cols: 2, rows: 1 },
    SiteExplorer: { cols: 2, rows: 2 },
    PCSPeakMonitoring: { cols: 2, rows: 2 },
    PCSRealTimeCurrents: { cols: 1, rows: 2 },
    PCSRealTimePower: { cols: 1, rows: 2 },
    PCSRealTimeVoltage: { cols: 1, rows: 2 },
    PCSLogs: { cols: 2, rows: 2 },
    CMUFD: {cols: 1, rows: 2},
    PDURealTimeCurrents: { cols: 1, rows: 2 },
    PDURealTimeVoltage: { cols: 1, rows: 2 },
    PDUPeakMonitoring: { cols: 2, rows: 2 },
    UMC: { cols: 1, rows: 2 },
    WeatherForecast48Hours: { cols: 2, rows: 1 }, 
    Frequency: { cols: 1, rows: 1 },
    CurrentWeather: { cols:1, rows: 1 },
    WeatherForecast: { cols: 1, rows: 2 },
    ATSSourceStatus: { cols: 1, rows: 2 },
    AssetPowerFactorTrend: { cols: 2, rows: 2 },
    AssetFrequencyTrend: { cols: 2, rows: 2 }
};


/* get the icon src of the add widget menu */
export const addWidgetMenuTemplateIcons = {
    RealTimeCurrents: 'assets/ABB UI Icon Package/SVG/RealTime.svg',
    RealTimeVoltage: 'assets/ABB UI Icon Package/SVG/RealTime.svg',
    UPSRealTimeCurrents: 'assets/ABB UI Icon Package/SVG/Data.svg',
    UPSRealTimeVoltage: 'assets/ABB UI Icon Package/SVG/Data.svg',
    UPSBatteryStatus: 'assets/ABB UI Icon Package/SVG/UPS-Battery.svg',
    RealTimePower: 'assets/ABB UI Icon Package/SVG/RealTime.svg',
    EnergyMonitoring: 'assets/ABB UI Icon Package/SVG/Bar.svg',
    EnergyCost: 'assets/ABB UI Icon Package/SVG/Cost.svg',
    GroupPeakMonitoring: 'assets/ABB UI Icon Package/SVG/moniter.svg',
    PeakMonitoring: 'assets/ABB UI Icon Package/SVG/moniter.svg',
    PowerFactor: 'assets/ABB UI Icon Package/SVG/Power.svg',
    PowerDemand: 'assets/ABB UI Icon Package/SVG/Power.svg',
    PowerGeneration: 'assets/ABB UI Icon Package/SVG/Power.svg',
    AnalogDataMonitoring: 'assets/ABB UI Icon Package/SVG/moniter.svg',
    GroupEnergyMix: 'assets/ABB UI Icon Package/SVG/group.svg',
    EnergyFlow: 'assets/ABB UI Icon Package/SVG/Flow.svg',
    Map: 'assets/ABB UI Icon Package/SVG/Location.svg',
    MultipleSiteLocator: 'assets/ABB UI Icon Package/SVG/Location.svg',
    HealthOverview: 'assets/ABB UI Icon Package/SVG/group.svg',
    ServiceOverview: 'assets/ABB UI Icon Package/SVG/group.svg',
    EventOverview: 'assets/ABB UI Icon Package/SVG/group.svg',
    ConnectivityOverview: 'assets/ABB UI Icon Package/SVG/group.svg',
    HealthTrend: 'assets/ABB UI Icon Package/SVG/Bar.svg',
    HealthByAge: 'assets/ABB UI Icon Package/SVG/Bar.svg',
    AssetList: 'assets/ABB UI Icon Package/SVG/server.svg',
    LatestEvents: 'assets/ABB UI Icon Package/SVG/Calendar.svg',
    EventsTrend: 'assets/ABB UI Icon Package/SVG/Bar.svg',
    ScheduledServices: 'assets/ABB UI Icon Package/SVG/Calendar.svg',
    ConnectivityStatusList: 'assets/ABB UI Icon Package/SVG/server.svg',
    ServiceActivityOverview: 'assets/ABB UI Icon Package/SVG/group.svg',
    DigitalDataMonitoring: 'assets/ABB UI Icon Package/SVG/moniter.svg',
    ConnectivityTrend: 'assets/ABB UI Icon Package/SVG/Bar.svg',
    ServiceActivities: 'assets/ABB UI Icon Package/SVG/Calendar.svg',
    LocalTime: 'assets/ABB UI Icon Package/SVG/localtime.svg',
    PerformanceMonitoring: 'assets/ABB UI Icon Package/SVG/moniter.svg',
    MeteringDataMonitoring: 'assets/ABB UI Icon Package/SVG/moniter.svg',
    CurrentTrends: 'assets/ABB UI Icon Package/SVG/moniter.svg',
    VoltageTrends: 'assets/ABB UI Icon Package/SVG/moniter.svg',
    DevicePowerData: 'assets/ABB UI Icon Package/SVG/moniter.svg',
    DataCenterPUE: 'assets/ABB UI Icon Package/SVG/moniter.svg',
    PowerForecast: 'assets/ABB UI Icon Package/SVG/moniter.svg',
    ARCGuard: 'assets/ABB UI Icon Package/SVG/Data.svg',
    ActiveEnergyAudit: 'assets/ABB UI Icon Package/SVG/Data.svg',
    EnergyData: 'assets/ABB UI Icon Package/SVG/Data.svg',
    EnergyCostComparison: 'assets/ABB UI Icon Package/SVG/Data.svg',
    GroupRealTimeVoltage: 'assets/ABB UI Icon Package/SVG/RealTime.svg',
    GroupRealTimePower: 'assets/ABB UI Icon Package/SVG/RealTime.svg',
    RealTimeMetering: 'assets/ABB UI Icon Package/SVG/Data.svg',
    GroupRealTimeMetering: 'assets/ABB UI Icon Package/SVG/Data.svg',
    GroupRealTimeCurrents: 'assets/ABB UI Icon Package/SVG/RealTime.svg',
    DataCenter: 'assets/ABB UI Icon Package/SVG/moniter.svg',
    UPSMonitor: 'assets/ABB UI Icon Package/SVG/Power.svg',
    PerformanceIndicator: 'assets/ABB UI Icon Package/SVG/Power.svg',
    StatesEvents: 'assets/ABB UI Icon Package/SVG/Data.svg',
    EnvironmentalData: 'assets/ABB UI Icon Package/SVG/Data.svg',
    TotalHistoricEnergyData: 'assets/ABB UI Icon Package/SVG/RealTime.svg',
    UPSAlarmPanelStatusData: 'assets/ABB UI Icon Package/SVG/RealTime.svg',
    InputDataCalculation: 'assets/ABB UI Icon Package/SVG/Power.svg',
    ATSParameters: 'assets/ABB UI Icon Package/SVG/RealTime.svg',
    TransferTime: 'assets/ABB UI Icon Package/SVG/RealTime.svg',
    PowerQuality: 'assets/ABB UI Icon Package/SVG/RealTime.svg',
    EnergyDataComparison: 'assets/ABB UI Icon Package/SVG/Data.svg',
    UPSAlarmStatus: 'assets/ABB UI Icon Package/SVG/RealTime.svg',
    HistoricDataMetering: 'assets/ABB UI Icon Package/SVG/Data.svg',
    PowerQualityVoltage: 'assets/ABB UI Icon Package/SVG/RealTime.svg',
    UPSRealTimePower: 'assets/ABB UI Icon Package/SVG/Data.svg',
    UPSEvents: 'assets/ABB UI Icon Package/SVG/Data.svg',
    UPSAlarm: 'assets/ABB UI Icon Package/SVG/Calendar.svg',
    UPSPeakMonitoring: 'assets/ABB UI Icon Package/SVG/moniter.svg',
    ArcGuardCSU2: 'assets/ABB UI Icon Package/SVG/Data.svg',
    MultiPeakMonitoring: 'assets/ABB UI Icon Package/SVG/moniter.svg',
    AssetEnergyTrend: 'assets/ABB UI Icon Package/SVG/moniter.svg',
    EnergyCompositionTrend: 'assets/ABB UI Icon Package/SVG/moniter.svg',
    EnergyCompositionOverview: 'assets/ABB UI Icon Package/SVG/group.svg',
    SiteExplorer: 'assets/ABB UI Icon Package/SVG/group.svg',
    PCSPeakMonitoring: 'assets/ABB UI Icon Package/SVG/moniter.svg',
    PCSRealTimeCurrents: 'assets/ABB UI Icon Package/SVG/Data.svg',
    PCSRealTimePower: 'assets/ABB UI Icon Package/SVG/Data.svg',
    PCSRealTimeVoltage: 'assets/ABB UI Icon Package/SVG/Data.svg',
    PCSLogs: 'assets/ABB UI Icon Package/SVG/Data.svg',
    PDURealTimeCurrents: 'assets/ABB UI Icon Package/SVG/Data.svg',
    PDURealTimeVoltage: 'assets/ABB UI Icon Package/SVG/Data.svg',
    PDUPeakMonitoring: 'assets/ABB UI Icon Package/SVG/moniter.svg',
    CMUFD: 'assets/ABB UI Icon Package/SVG/Data.svg',
    UMC: 'assets/ABB UI Icon Package/SVG/Data.svg',
    WeatherForecast48Hours: 'assets/ABB UI Icon Package/SVG/weather.svg',
    Frequency: 'assets/ABB UI Icon Package/SVG/Power.svg',
    CurrentWeather: 'assets/ABB UI Icon Package/SVG/weather.svg',
    WeatherForecast: 'assets/ABB UI Icon Package/SVG/weather.svg',
    ATSSourceStatus: 'assets/ABB UI Icon Package/SVG/Data.svg',
    AssetPowerFactorTrend: 'assets/ABB UI Icon Package/SVG/moniter.svg',
    AssetFrequencyTrend: 'assets/ABB UI Icon Package/SVG/moniter.svg',
};


/* Default image */
export const defaultImage = {
    Plant: 'assets/ABB UI Icon Package/SVG/home-plant.svg', // used in site tree page
    Device: 'assets/DefaultAsset_tmp.png',
    GroupRealTimePower: 'assets/ABB UI Icon Package/SVG/RealTime.svg',
    RealTimeMetering: 'assets/ABB UI Icon Package/SVG/RealTime.svg',
    GroupRealTimeMetering: 'assets/ABB UI Icon Package/SVG/Data.svg',
};

/* widget size declaration on small screen*/
export const gridWidgetsDynamiconSmallScreen = {
    RealTimeCurrents: { cols: 1, rows: 2 },
    UPSRealTimeCurrents: { cols: 1, rows: 2 },
    UPSRealTimeVoltage: { cols: 1, rows: 2 },
    UPSBatteryStatus: { cols: 1, rows: 1},
    RealTimePower: { cols: 1, rows: 2 },
    RealTimeVoltage: { cols: 1, rows: 2 },
    EnergyCost: { cols: 1, rows: 2 },
    PowerFactor: { cols: 1, rows: 1 },
    Map: { cols: 6, rows: 3 },
    MultipleSiteLocator: { cols: 6, rows: 6 },
    EnergyMonitoring: { cols: 6, rows: 6 },
    PeakMonitoring: { cols: 6, rows: 6 },
    GroupPeakMonitoring: { cols: 6, rows: 6 },
    DigitalDataMonitoring: { cols: 6, rows: 6 },
    AnalogDataMonitoring: { cols: 6, rows: 6 },
    HealthOverview: { cols: 6, rows: 3 },
    ServiceActivityOverview: { cols: 6, rows: 3 },
    PowerGeneration: { cols: 6, rows: 3 },
    PowerDemand: { cols: 6, rows: 3 },
    EventOverview: { cols: 6, rows: 3 },
    ConnectivityOverview: { cols: 6, rows: 3 },
    latestEvents: { cols: 6, rows: 6 },
    EventsTrend: { cols: 6, rows: 6 },
    HealthByAge: { cols: 6, rows: 3 },
    ConnectivityTrend: { cols: 6, rows: 6 },
    GroupEnergyMix: { cols: 6, rows: 3 },
    LatestEvents: { cols: 6, rows: 6 },
    AssetList: { cols: 6, rows: 6 },
    ServiceActivities: { cols: 6, rows: 6 },
    LocalTime: { cols: 1, rows: 1 },
    PerformanceMonitoring: { cols: 6, rows: 6 },
    MeteringDataMonitoring: { cols: 6, rows: 6 },
    CurrentTrends: { cols: 6, rows: 6 },
    VoltageTrends: { cols: 6, rows: 6 },
    DevicePowerData: { cols: 6, rows: 6 },
    DataCenterPUE: { cols: 6, rows: 6 },
    PowerForecast: { cols: 6, rows: 6 },
    ARCGuard: { cols: 1, rows: 2 },
    ActiveEnergyAudit: { cols: 1, rows: 2 },
    EnergyData: { cols: 6, rows: 6 },
    EnergyCostComparison: { cols: 1, rows: 2 },
    GroupRealTimeVoltage: { cols: 1, rows: 2 },
    GroupRealTimePower: { cols: 1, rows: 2 },
    RealTimeMetering: { cols: 1, rows: 2 },
    GroupRealTimeMetering: { cols: 1, rows: 2 },
    GroupRealTimeCurrents: { cols: 1, rows: 2 },
    PerformanceIndicator: { cols: 1, rows: 1 },
    StatesEvents: { cols: 1, rows: 2 },
    DataCenter: { cols: 6, rows: 3 },
    UPSMonitor: { cols: 6, rows: 6 },
    EnvironmentalData: { cols: 1, rows: 2 },
    TotalHistoricEnergyData: { cols: 1, rows: 2 },
    UPSAlarmPanelStatusData: { cols: 1, rows: 2 },
    InputDataCalculation: { cols: 1, rows: 1 },
    ATSParameters: { cols: 1, rows: 2 },
    TransferTime: { cols: 6, rows: 6 },
    PowerQuality: { cols: 1, rows: 1 },
    EnergyDataComparison: { cols: 1, rows: 2 },
    HistoricDataMetering: { cols: 1, rows: 2 },
    PowerQualityVoltage: { cols: 1, rows: 1 },
    UPSRealTimePower: { cols: 1, rows: 2 },
    UPSEvents: { cols: 2, rows: 2 },
    UPSAlarm: { cols: 1, rows: 2 },
    UPSPeakMonitoring: { cols: 6, rows: 6 },
    UPSAlarmStatus: { cols: 1, rows: 2 },
    ArcGuardCSU2: { cols: 1, rows: 1 },
    MultiPeakMonitoring: { cols: 6, rows: 6 },
    AssetEnergyTrend: { cols: 6, rows: 6 },
    EnergyCompositionTrend: { cols: 6, rows: 6 },
    EnergyCompositionOverview: { cols: 6, rows: 3 },
    PCSPeakMonitoring: { cols: 2, rows: 2 },
    PCSRealTimeCurrents: { cols: 1, rows: 2 },
    PCSLogs: { cols: 2, rows: 2 },
    PCSRealTimePower: { cols: 1, rows: 2 },
    PCSRealTimeVoltage: { cols: 1, rows: 2 },
    CMUFD: {cols: 1, rows: 2},
    PDURealTimeCurrents: { cols: 1, rows: 2 },
    PDURealTimeVoltage: { cols: 1, rows: 2 },
    PDUPeakMonitoring: { cols: 2, rows: 2 },
    UMC: { cols: 1, rows: 2 },
    WeatherForecast48Hours: {cols: 2, rows: 1},
    Frequency: { cols: 1, rows: 1 },
    CurrentWeather: {cols: 1, rows:1 },
    WeatherForecast: { cols: 1, rows: 2 },
    ATSSourceStatus: {cols: 1, rows: 2},
    AssetPowerFactorTrend: {cols: 2, rows: 2 },
    AssetFrequencyTrend: { cols: 6, rows: 6 }
};


export const ercGuardARUC2Column = [
    {
      name: 'description',
      displayName: 'CSU2',
      translateKey: 'listTable.CSU2',
      type: 'string',
      sort: false,
      ellipsis: true
    }
  ];

  export const ercGuardARUC2Column2Row = [
    {
      name: 'daisyChainStatus',
      displayName: 'State',
      translateKey: 'listTable.state',
      type: 'string',
      sort: false,
      ellipsis: true
    },
    {
      name: 'activeError',
      displayName: 'Error',
      translateKey: 'listTable.error',
      type: 'string',
      sort: false,
      ellipsis: true
    },
    {
      name: 'tripDate',
      displayName: 'OC Trip',
      translateKey: 'listTable.OCTrip',
      type: 'string',
      isTripped: 'isTripped',
      sort: false,
      ellipsis: true,
      isDate: true
    },
    {
      name: 'warningDate',
      displayName: 'OC Warning',
      translateKey: 'listTable.OCWarning',
      type: 'string',
      isWarning: 'isWarning',
      sort: false,
      ellipsis: true,
      isDate: true
    }
  ];

export const colSpanByBreakpoint = {
    xl: 12,
    lg: 12,
    md: 8,
    sm: 8,
    xs: 6
};

/* This const is used to add panel limitation in site hierarchy screen */
export const addPanelSetting = 15;

/* Default page size declaration */
export const pageSize = {
    size: 14,
    settingsTable: 5
};


export const plantType = 'EDCS';

/* This constant is used to check the condition */
export const plantsType = {
    EDCS: 'EDCS',
    MRC2: 'MRC2',
    MRC3: 'MRC3',
    EL: 'EL'
};

/* symbols declaration */
export const symbols = {
    dollar: '$',
    euro: '€'
};

/* symbols declaration */
export const mapConfig = {
    image: '/assets/marker.svg',
    minZoom: 2,
    zoom: 16
};

export const ErrorConstants = {
    nameRequired: 'Name is required',
};
/* Dropdown Types */
export const dropdownTypes = {
    basicDropdown: 'dropDownBasic',
    searchDropdown: 'dropDownWithSearch',
    templateDropdown: 'dropDownWithImage',
    multiple: 'multiple',
    multipleCheckbox: 'multipleCheckbox'
};
/* Placeholder content  */
export const tableAssetPlaceholder = {
    tableAssetPlaceholder: 'Select asset...'
};
/* Dropdown widths  */
export const dropDownWidths = {
    basicDropdownWidth: '100',
    searchDropdownWidth: '130'
};

/* Time Zone labels for various countries */
export const timeZone = {
    europeLabel: 'en-US'
};

/* Below object declaration to identified the widget chart type */
export const chartWidget = {
    healthByAge: 'HealthByAge',
    energyMonitor: 'EnergyMonitor',
    lineChart: 'lineChart',
    eventTrend: 'eventTrend',
    connectivityTrend: 'connectivityTrend',
    powerData: 'powerData',
    eventAssetList: 'eventAssetList',
    maintenancePrediction: 'maintenancePrediction',
    circuitBreakerSummary: 'circuitBreakerSummary',
    timeNextMaintenance: 'timeNextMaintenance',
    environmentalData: 'environmentalData',
    groupRealTimePowerData: 'groupRealTimePowerData',
    assetPowerData: 'assetPowerData',
    pueMonitor: 'pueMonitor',
    upsMonitor: 'upsMonitor',
    groupRealTimeVoltageData: 'groupRealTimeVoltageData',
    energyData: 'energyData',
    healthOverview: 'healthOverview',
    energyMixGroup: 'energyMixGroup',
    smsNotificationOverview: 'smsNotificationOverview',
    connectivityOverview: 'connectivityOverview',
    eventOverview: 'eventOverview',
    serviceActivitiesOverview: 'serviceActivitiesOverview',
    realTimeCurrent: 'realTimeCurrent',
    realTimePower: 'realTimePower',
    realTimeVoltage: 'realTimeVoltage',
    upsRealTimeVoltage: 'upsRealTimeVoltage',
    MrcLineChart: 'MrcLineChart',
    tempertureTrendLineChart: 'tempertureTrendLineChart',
    mechanicalTrendLineChart: 'mechanicalTrendLineChart',
    UPSRealTimePower: 'UPSRealTimePower',
    UPSEvents: 'UPSEvents',
    upsRealTimeCurrents: 'upsRealTimeCurrents',
    upsRealTimePower: 'upsRealTimePower',
    multiPeakMonitoring: 'multiPeakMonitoring',
    assetEnergyTrend: 'assetEnergyTrend',
    energyCompositionTrend: 'energyCompositionTrend',
    EnergyCompositionOverview: 'EnergyCompositionOverview',
    pdcom: 'pdcom',
    PCSRealTimeCurrents: 'PCSRealTimeCurrents',
    PCSLogs: 'PCSLogs',
    PCSRealTimePower: 'PCSRealTimePower',
    pcsRealTimeVoltage: 'pcsRealTimeVoltage',
    PDURealTimeCurrents: 'PDURealTimeCurrents',
    PDURealTimeVoltage: 'PDURealTimeVoltage',
    dataAnalysisLineChart: 'dataAnalysisLineChart', 
    WeatherForecast48Hours: 'WeatherForecast48Hours',
    dielectricColumnChart: 'dielectricColumnChart',
    dielectricLineChart: 'dielectricLineChart',
    dielectricColumnRangeChart: 'dielectricColumnRangeChart',
    dielectricHorizondalBarChart: 'dielectricHorizondalBarChart',
    dielectricHorizondalBarChartXAxis: 'dielectricHorizondalBarChartXAxis',
    dielectricHorizondalBarChartLegend: 'dielectricHorizondalBarChartLegend',
    monitoringSeriesDataLineChart: 'monitoringSeriesDataLineChart',
    assetServiceChart:'assetServiceChart',
    powerLossData:'powerLossData',
    hourlyXAxisLineChart: 'hourlyXAxisLineChart',
    TrendAnalogChart:'TrendAnalogChart'
};

/* set the color of the contractual power line chart */
export const chartColor = {
    contractualPowerColor: '#FF7300',
    splineChartColor: '#4C85FF',
    Temp1: '#B5AA0D',
    Temp2: '#5ABFAE',
    Temp3: '#1D5F53',
    IL1: '#4C85FF',
    IL2: '#F7C530',
    IL3: '#FF9F8C',
    U1: '#4C85FF',
    U2: '#F7C530',
    U3: '#FF9F8C',
    L2U1: '#8e5ea2',
    L2U2: '#19198c',
    L2U3: '#b3b5c6',
    Active: '#4C85FF',
    Reactive: '#F7C530',
    Apparent: '#FF9F8C',
    Group: '#4C85FF',
    compareGroup: '#FF7300',
    previousPower: '#4C85FF',
    confidenceInterval: '#D2D2D2',
    average: '#C2347B',
    nextMaintenanceDateColor: '#7C5295'
};

/* constants for all assets header */
export const allAssetsConstants = {
    name: 'name',
    condition: 'condition',
    connection: 'connection',
    class: 'class',
    manufacturer: 'manufacturer',
    model: 'model',
    serialNumber: 'serialNumber',
    healthIndex: 'healthIndex'
};

export const DEFAULT_CONFIRM_DIALOG_CFG = {
    width: '80vw',
    maxWidth: '420px',
    height: '195px',
    panelClass: 'dialog-container',
}

/* delete modal popup configuration */
export const deleteWidgetPopupConfig = {
    width: '80vw',
    maxWidth: '490px',
    height: '120px',
    data: {
        Title: ' ',
        subTitle: 'Only 25 widgets can be added per dashboard',
        buttonText: 'OK',
        displayCancelButton: false
    }
};

export const clearSelectedTabPopupConfig = {
    width: '80vw',
    maxWidth: '460px',
    height: '180px',
    panelClass: 'dialog-container',
    data: {
        Title: 'If you change item type your configuration will be lost!',
        subTitle: `This action can't be undone`,
        buttonText: 'OK',
        displayCancelButton: true
    }
};

/* line chart constants */
export const lineChartConstants = {
    digitalDataMonitoring: 'digitalDataMonitoring',
    analogDataMonitoring: 'analogDataMonitoring',
    peakMonitoring: 'peakMonitoring',
    groupPeakMonitoring: 'groupPeakMonitoring',
    currentTemperature: 'currentTemperature',
    maintenancePrediction: 'maintenancePrediction',
    mechanicalTrend: 'mechanicalTrend',
    breakerOperations: 'breakerOperations',
    multiPeakMonitoring: 'multiPeakMonitoring',
};


/*line chart legend name constants*/
export const legendNames = {
    activePower: 'Active power',
    count: 'Count',
    temperature: 'Temperature(°C)',
    contractualPower: 'Contractual power',
    nextMaintenanceDate: 'Next maintenance date',
    il1: 'IL1',
    il2: 'IL2',
    il3: 'IL3',
    temp1: 'Temp1',
    temp2: 'Temp2',
    temp3: 'Temp3',
    mp: 'MP',
    u1: 'U1',
    u2: 'U2',
    u3: 'U3',
    l2u1: 'L2U1',
    l2u2: 'L2U2',
    l2u3: 'L2U3',
    active: 'Active',
    reactive: 'Reactive',
    apparent: 'Apparent',
    group: 'Group',
    compareGroup: 'Compare Group',
    breakerOperations: 'Breaker Operations',
    avg: 'Avg',
    AvgF: 'AvgF'
 };

/* dashboard panel name constants */
export const dashboardPanelName = {
    EDCS: 'Energy',
    MRC3: 'Asset',
    MRC2: 'Asset',
    EL: 'EL',
};

/* dashboard snack bar message constants */
export const snackBarMessage = {
    dashboardDeletedMessage: 'Dashboard Deleted',
    defaultDashboardMessage: 'Default Dashboard Created',
    customDashboardMessage: 'Custom Dashboard Created',
    templateAddedMessage: 'Custom Template Added',
    dashboardRenameSuccess: 'Dashboard Name Updated',
    dashboardRenameFail: 'Dashboard Name Update Failed',
    dashboardRenamewithSame: 'Dashboard name is unchanged',
    templateNotAddedMessage: 'Custom Template Addition Failed',
    exceededMaxLimit: 'Cannot add more than 15 panels'

};


// Maximum widgets can be added per panel is 25
export const maxWidgetPerPanel = 25;

// to store common error types
export const errorType = {
    widgetNotSupported: 'WidgetNotSupported',
    NegativeResidue: 'Negative Residue',
    DuplicatedGroup: 'Duplicated Group',
};

export const errorValidation = {
    requiredField: ' is required',
    invalid: 'Invalid'
};


export const favouritesLimit = 20;

// to store the dialog menu header
export const dialogMenuHeader = {
    editDashboard: 'edit dashboard',
    addDashboard: 'add a new dashboard'
};

export const assetDetailsSettings = {
    digitalInput: 'DigitalInput',
    digitalOutput: 'DigitalOutput',
    analogInput: 'AnalogInput',
    nameEmptyErrorMsg: 'Name is required',
    nameLengthErrorMsg: 'Name length has to be between 2 and 50 characters',
    noteLengthError: 'Note length has to be 50 characters maximum',
    additionalNumberOfOperationsLengthError: 'Additional number of operations required',
    contactWearT1PercentageLengthError: 'Contact wear(T1) percentage required',
    cbPolesError: 'Asset poles required',
    cbTypeError: 'Asset type required',
    standardReferenceError: 'Standard reference required',
    cbFamilyError: 'Asset family required',
    cbVersionError: 'Asset version required'
};

export const ServiceContract = {
    technicianNameEmptyErrorMsg: 'Name length has to be 50 characters maximum',
    technicianSurnameEmptyErrorMsg: 'Surname length has to be 50 characters maximum',
    technicianCompanyEmptyErrorMsg: 'Company length has to be 50 characters maximum',
    technicianEmailEmptyErrorMsg: 'Email not valid',
    technicianPhoneEmptyErrorMsg: 'Phone not valid. Format: [+][countrycode][number]',
};

export const dropDownDataActiveInterval = {
    0: { from: '00:00', to: '00:59' },
    1: { from: '01:00', to: '00:59' },
    2: { from: '02:00', to: '01:59' },
    3: { from: '03:00', to: '02:59' },
    4: { from: '04:00', to: '03:59' },
    5: { from: '05:00', to: '04:59' },
    6: { from: '06:00', to: '05:59' },
    7: { from: '07:00', to: '06:59' },
    8: { from: '08:00', to: '07:59' },
    9: { from: '09:00', to: '08:59' },
    10: { from: '10:00', to: '09:59' },
    11: { from: '11:00', to: '10:59' },
    12: { from: '12:00', to: '11:59' },
    13: { from: '13:00', to: '12:59' },
    14: { from: '14:00', to: '13:59' },
    15: { from: '15:00', to: '14:59' },
    16: { from: '16:00', to: '15:59' },
    17: { from: '17:00', to: '16:59' },
    18: { from: '18:00', to: '17:59' },
    19: { from: '19:00', to: '18:59' },
    20: { from: '20:00', to: '19:59' },
    21: { from: '21:00', to: '20:59' },
    22: { from: '22:00', to: '21:59' },
    23: { from: '23:00', to: '22:59' },
    24: { from: '24:00', to: '23:59' }

};

export const dayNames = {
    monday: 'Monday',
    tuesday: 'Tuesday',
    wednesday: 'Wednesday',
    thursday: 'Thursday',
    friday: 'Friday',
    saturday: 'Saturday',
    sunday: 'Sunday'
};
export const EnvironmentEditData = {
    presetIdErrorMsg: 'Preset is required',
    averageYearlyTemperatureErrorMsg: 'Average yearly temperature required',
    dustErrorMsg: 'Dust required',
    humidityErrorMsg: 'Humidity required',
    saltErrorMsg: 'Salt required',
    sO2CorrosionErrorMsg: 'SO2 corrosion required',
    vibrationErrorMsg: 'Vibration required',
    voltageErrorMsg: 'Voltage required',
    descriptionErrorMsg: 'Description length not valid'
};

export const MaintenanceData = {
    dueDateErrorMsg: 'Due date is required',
    descriptionErrorMsg: 'Description is required',
    executionDateErrorMsg: 'Execution date required',
    AssetErrorMsg: 'Select asset',
    dueDateMinDateError: 'Due date cannot be less than current date',
    assignedErrormsg: 'No user assigned',
    descriptionLengthMsg: 'Description length should be less than or equal to 1000 characterss'
};

export const setIntervalData = {
    timeDuration: 60 * 1000,
    reportInterval: 10 * 1000
};

/* Json data to display languages dropdown */
export const Languages = [
    { Language: 'Deutsch', Languagecode: 'de' },
    { Language: 'English (International)', Languagecode: 'en' },
    { Language: 'English (United States)', Languagecode: 'en' },
    { Language: 'Español', Languagecode: 'es' },
    { Language: 'Français', Languagecode: 'fr' },
    { Language: 'Italiano', Languagecode: 'it' },
    { Language: 'Polski', Languagecode: 'pl' },
    { Language: 'Portuguese', Languagecode: 'pt' },
    { Language: 'Русский', Languagecode: 'ru' },
    { Language: '中国', Languagecode: 'zh' },
];

export const NotApplicableData = {
    notApplicable: 'N.A.'
};

export const trendsConstants = {
    customPeriodText: 'Custom'
};

export const TriggersTitle = {
    newAlertTitle: 'New alert condition',
    editAlertTitle: 'Edit alert condition'
};

export const triggersConstant = {
    triggersModeDisconnected: 'Disconnected',
    triggersModeStatusChange: 'StatusChange',
    triggersModeThreshold: 'Threshold',
    triggersModeIntelligent: 'Intelligent',
    activation: 'activation',
    deActivation: 'de-activation',
    moreThan: 'More Than',
    lessThan: 'Less Than',
    dropDownTypeFrom: 'from',
    dropDownTypeTo: 'to',
    subscribedUsersProfiles: 'SubscribedUsersProfiles',
    allAlertProfiles: 'AllAlertProfiles',
    methodPost: 'post',
    methodPut: 'put'
};

export const addItemSettingsTriggers = {
    width: '450px',
    height: '350px',
    position: {
        bottom: '55px',
        right: '80px'
    },
    data: {},
    backdropClass: 'backdropBackground'
};

export const truOneParametesConstants = {
    tempL1: 'L1 temperature',
    tempL2: 'L2 temperature',
    tempL3: 'L3 temperature',
    tempN: 'N temperature',
    internalTemperature: 'ATS internal temperature',
    displayTemperature: 'Display temperature',
    nLoadTransf: 'Number of load transfers',
    transfTime: 'Transfer time',
    sourceFailTransfers: 'Source fail transfers',
    energizedDays: 'Days with TryOne energized',
    s1AvailableMinutes: 'Time S1 available',
    s1TotalMinutes: 'Total time on S1',
    s2AvailableMinutes: 'Time S2 available',
    s2TotalMinutes: 'Total time on S2',
    generatorStartSeconds: 'Generator start time',
    generatorLastStart: 'Generator last start time',
    inPhaseTimeSeconds: 'In-phase time'
};

export const smsNotificationConstants = {
    smsNotificationEnabled: 'SMS notification enabled',
    smsNotificationDisabled: 'SMS notification disabled',
    numberOfMessageSent: 'numberOfMessageSent',
    numberOfMessageAllowed: 'numberOfMessageAllowed',
    smsNotificationOverview: 'smsNotificationOverview',
    usedText: 'Used',
    totalAvailableText: 'Total available',
    StillAvailableText: 'Still available',
    colorBlue: '#4C85FF',
    colorGrey: '#DBDBDB',
    colorLightBlue: '#B7DAFD',
};

export const GenerateReportErrorMsg = {
    reportTypeErrorMsg: 'Report type is required',
    equipmentErrorMsg: 'At least one device is required',
    groupErrorMsg: 'At least one group is required',
    nameErrorMsg: 'Name is required',
    rawDataErrorMsg: 'Raw data is only available for 5 or less selected devices.'
};

export const assetInformationConstants = {
    CB_tag_name: 'cbTagName',
    // Tag_name: 'tagName',
    Nominal_current: 'nominalCurrent',
    Serial_number: 'serialNumber',
    Device_ID: 'deviceId',
    // Number_of_poles: 'numberOfPoles',
    CB_serial_number: 'cbSerialNumber',
    Primary_voltage: 'primaryVoltage',
    Product_execution: 'productExecution',
    // Manufacturer: 'manufacturer',
    // Model: 'model',
    // Rating: 'rating',
    // siteId: 'siteId',
    // InstallationId: 'installationId',
    // ShortCircuitCurrent: 'shortCircuitCurrent',
    // Nominal_voltage: 'application',
    // NominalVoltage: 'nominalVoltage',
    // Device_Hub_Serial_Number: 'deviceHubSerialNumber',
    // Plant_Id: 'plantId',
    // Host_Serial_Number: 'hostSerialNumber',
    // Is_Main: 'isMain',
    // Is_Generator: 'isGenerator',
    // Notes_Key: 'notes',
    // Installation_Date: 'installationDate',
    // Is_CB_Linked: 'isCBLinked',
    // CB_Installation_Date: 'cbInstallationDate',
    // CB_Version: 'cbVersion',
    // CB_Family: 'cbFamily',
    Standard_Reference: 'standardReference',
    CB_Type: 'cbType',
    // CB_Poles: 'cbPoles',
    // Additional_Number_Of_Operations: 'additionalNumberOfOperations',
    // Contact_Wear_T1_Percentage: 'contactWearT1Percentage',
    // Contact_Wear_T2_Percentage: 'contactWearT2Percentage',
    // Environmental_Preset_Id: 'cnvironmentalPresetId',
    // Equipment_Status: 'equipmentStatus',
    // Slave_Id: 'slaveId',
    // Device_Name: 'deviceName',
    // Device_Type_Code: 'deviceTypeCode',
    // Is_Main_Enabled: 'isMainEnabled',
    // Is_Generator_Enabled: 'isGeneratorEnabled',
    // Is_Analog_Input_Enabled: 'isAnalogInputEnabled',
    // Is_Current_Enabled: 'isCurrentEnabled',
    // Is_Digital_Input_Enabled: 'isDigitalInputEnabled',
    // Is_Digital_Output_Enabled: 'isDigitalOutputEnabled',
    // Is_Energy_Enabled: 'isEnergyEnabled',
    // Is_Network_Analyzer_Enabled: 'isNetworkAnalyzerEnabled',
    // Is_Power_Enabled: 'isPowerEnabled',
    // Is_Power_Factor_Enabled: 'isPowerFactorEnabled',
    // Is_Voltage_Enabled: 'isVoltageEnabled',
    // Is_Advanced_Predictive_Maintenance: 'isAdvancedPredictiveMaintenance',
    // Is_Transfer_Switch_Enabled: 'isTransferSwitchEnabled',
    // Is_Current_Sensing_Enabled: 'isCurrentSensingEnabled',
    // CB_Status: 'cbStatus',
    // State_Input1: 'stateInput1',
    // State_Input2: 'stateInput2',
    // State_Input3: 'stateInput3',
    // State_Input4: 'stateInput4',
    // State_Input5: 'stateInput5',
    // State_Input6: 'stateInput6',
    // State_Input7: 'stateInput7',
    // State_Input8: 'stateInput8',
    // State_Input9: 'stateInput9',
    // State_Input10: 'stateInput10',
    // State_Input11: 'stateInput11',
    // CB_Pos: 'cbPos',
    // Operative_Mode: 'operativeMode',
    Any_Alarm: 'anyAlarm',
    Any_Trip_Alarm: 'anyTripAlarm',
    Name_Signalling_TCP: 'nameSignallingTCP',
    TagName_In1: 'tagNameIn1',
    TagName_In2: 'tagNameIn2',
    TagName_In3: 'tagNameIn3',
    TagName_In4: 'TtagNameIn4',
    TagName_In5: 'tagNameIn5',
    TagName_In6: 'tagNameIn6',
    TagName_In7: 'tagNameIn7',
    TagName_In8: 'tagNameIn8',
    TagName_In9: 'tagNameIn9',
    TagName_In10: 'tagNameIn10',
    TagName_In11: 'tagNameIn11',
    Pole_Number: 'poleNumber',
    CB_Execution: 'cbExecution',
    // Ekip_Com_Hub_Software_Version: 'ekipComHubSoftwareVersion',
    // Ekip_Com_Hub_Software_Version_Description: 'ekipComHubSoftwareVersionDescription',
    // Switch_Installation_Date: 'switchInstallationDate',
    // Device_Mode: 'deviceMode',
    // L1_Status: 'l1Status',
    // L2_Status: 'l2Status',
    NSw_Pos: 'nswPos',
    // HMI_Id: 'hmiId',
    Type_Code: 'typeCode',
    Type_Designation: 'typeDesignation',
    Firmware_Version: 'firmwareVersion',
    Phase_Configuration: 'phaseConfiguration',
    // Number_Of_Operations: 'numberOfOperations',
    // Out_V1: 'outV1',
    // Out_V2: 'outV2',
    // Out_V3: 'outV3',
    // Batt_Temp: 'battTemp',
    // Frequency_Key: 'frequency',
    // CM_Error_Summary: 'cmErrorSummary',
    // CM_Restart_Delay: 'cmRestartDelay',
    // CM_Relay1: 'cmRelay1',
    // CM_Relay2: 'cmRelay2',
    // CM_Relay3: 'cmRelay3',
    // CM_Input_Y1: 'cmInputY1',
    // CM_Input_Y2: 'cmInputY2',
    // CM_Input_Y3: 'cmInputY3',
    // Last_Maintenance: 'lastMaintenance',
    // Number_Of_Extension_Units: 'numberOfExtensionUnits',
    // External_HMI: 'externalHMI',
    // CSU0_key: 'csu0',
    // CSU1_key: 'csu1',
    // CSU2_key: 'csu2',
    // Electrical_Life_Percentage: 'electricalLifePercentage',
    // Installed_Modules: 'installedModules',
    // TVOC_Trip_Detector_Inputs: 'tvocTripDetectorInputs',
    // Sensors_key: 'sensors',
    // PCS100_Status: 'pcS100Status',
    // PCS100_Warning_Indication: 'pcS100WarningIndication',
    // PCS100_Inhibit_Indication: 'pcS100InhibitIndication',
    // PCS100_Active_Event_Code: 'pcS100ActiveEventCode',
    PCS100_Product_Code: 'pcS100ProductCode',
    PCS100_Rated_Current: 'pcS100RatedCurrent',
    PCS100_Rated_Voltage: 'pcS100RatedVoltage',
    PCS100_Rated_Frequency: 'pcS100RatedFrequency',
    // PCS100_Device_Events: 'pcS100DeviceEvents',
    // Transfer_Time_Threshold: 'transferTimeThreshold',
    Is_System_Trip: 'isSystemTrip',
    Is_System_Warning: 'isSystemWarning',
    Is_System_Error: 'isSystemError',
    // Sensing_Infos: 'sensingInfos',
    // Sensing_Warnings: 'sensingWarnings',
    // Sensing_Errors: 'sensingErrors',
    ratedI: 'ratedI',
    swType: 'swType',
    fblown: 'fblown',
};

/** @description used in asset information page. */
export const stateInformationConstants = {
    PCS100_Status: 'pcS100Status',
     PCS100_Warning_Indication: 'pcS100WarningIndication',
     PCS100_Inhibit_Indication: 'pcS100InhibitIndication',
}

/** @description used in asset information page. */
export const upsStateConstants = {
    iups_Warning_Indication: 'iupsWarningIndication',
    iups_Status: 'iupsStatus',
}

export const ElectronicDevicesConstants = {
    Trip_unit_type: 'tripUnitType',
    Mainboard_software_version: 'mainBoardSoftwareVersion',
    Mainboard_serial_number: 'mainBoardSN',
    Trip_unit_software_version: 'tripUnitSoftwareVersion',
    Trip_Unit_SN: 'tripUnitSN',
    EkipComHubSoftwareVersion: 'ekipComHubSoftwareVersion',
    Device_type: 'deviceType',
    Modbus_address: 'modbusAddress',
    Version: 'version',
    Firmware: 'firmware',
    Installed_Ekip_Com_Hub_Serial_Number: 'installedEkipComHubSerialNumber',
    Software_Version_Signalling_TCP: 'softwareVersionSignallingTCP',
    SW_Ver: 'swVer'
};

export const LifeCycleDataConstants = {
    Installation_date: 'installationDate',
    Manual_operation: 'manualOperation',
    Total_operations: 'totalOperation',
    Number_of_trips: 'numberOfTrips',
    Contact_wear: 'contactWear',
    Total_Operations_Input1: 'totalOperationsInput1',
    Total_Operations_Input2: 'totalOperationsInput2',
    Total_Operations_Input3: 'totalOperationsInput3',
    Total_Operations_Input4: 'totalOperationsInput4',
    Total_Operations_Input5: 'totalOperationsInput5',
    Total_Operations_Input6: 'totalOperationsInput6',
    Total_Operations_Input7: 'totalOperationsInput7',
    Total_Operations_Input8: 'totalOperationsInput8',
    Total_Operations_Input9: 'totalOperationsInput9',
    Total_Operations_Input10: 'totalOperationsInput10',
    Total_Operations_Input11: 'totalOperationsInput11',
    Temp_L1: 'tempL1',
    Temp_L2: 'tempL2',
    Temp_L3: 'tempL3',
    Temp_N: 'tempN',
    Temp_Int: 'tempInt',
    N_Load_Transf: 'nLoadTransf',
    Transf_Time: 'transfTime',
    // Fb_lown: 'fblown',
    CM_TripR: 'cmTripR',
    CM_Freq_Value_Invalid: 'cmFreqValueInvalid',
    Display_Temperature: 'displayTemperature',
    Source_Fail_Transfers: 'sourceFailTransfers',
    Energized_Days: 'energizedDays',
    S1_Available_Minutes: 's1AvailableMinutes',
    S1_Total_Minutes: 's1TotalMinutes',
    S2_Available_Minutes: 's2AvailableMinutes',
    S2_Total_Minutes: 's2TotalMinutes',
    // Generator_Last_Start: 'generatorLastStart',
    Generator_Start_Seconds: 'generatorStartSeconds',
    In_Phase_Time_Seconds: 'inPhaseTimeSeconds',
};



export const energyDataCategories = ['Active energy', 'Reactive energy', 'Apparent energy'];

export const CreateDataGroupErrorMsg = {
    dataGroupTypeErrorMsg: 'Group type is required',
    nameErrorMsg: 'Name is required',
    itemsErrorMsg: 'At least one item is required',
    nameLengthErrorMsg: 'Name length has to be between 2 and 50 characters',
    incomingGroupErrorMsg: 'Incoming item is required',
    outgoingGroupErrorMsg: 'Outgoing item is required'
};

/* delete modal popup configuration */
export const tabschangeConfirmText = {
    text: 'If you change item type your configuration will be lost!',
    maxPanels: 'Maximun 15 panels can be Added',
    OkButtonText: 'Ok'
};

export const tabsLength = {
    maxTabsLength: 15
};

export const plantTypeNavigation = {
    mrc2: 'MRC2',
    mrc3: 'MRC3'
};
export const pdfData = {
    logoUrl: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gKgSUNDX1BST0ZJTEUAAQEAAAKQbGNtcwQwAABtbnRyUkdCIFhZWiAH4QAMAAgABQALAC1hY3NwQVBQTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9tYAAQAAAADTLWxjbXMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAtkZXNjAAABCAAAADhjcHJ0AAABQAAAAE53dHB0AAABkAAAABRjaGFkAAABpAAAACxyWFlaAAAB0AAAABRiWFlaAAAB5AAAABRnWFlaAAAB+AAAABRyVFJDAAACDAAAACBnVFJDAAACLAAAACBiVFJDAAACTAAAACBjaHJtAAACbAAAACRtbHVjAAAAAAAAAAEAAAAMZW5VUwAAABwAAAAcAHMAUgBHAEIAIABiAHUAaQBsAHQALQBpAG4AAG1sdWMAAAAAAAAAAQAAAAxlblVTAAAAMgAAABwATgBvACAAYwBvAHAAeQByAGkAZwBoAHQALAAgAHUAcwBlACAAZgByAGUAZQBsAHkAAAAAWFlaIAAAAAAAAPbWAAEAAAAA0y1zZjMyAAAAAAABDEoAAAXj///zKgAAB5sAAP2H///7ov///aMAAAPYAADAlFhZWiAAAAAAAABvlAAAOO4AAAOQWFlaIAAAAAAAACSdAAAPgwAAtr5YWVogAAAAAAAAYqUAALeQAAAY3nBhcmEAAAAAAAMAAAACZmYAAPKnAAANWQAAE9AAAApbcGFyYQAAAAAAAwAAAAJmZgAA8qcAAA1ZAAAT0AAACltwYXJhAAAAAAADAAAAAmZmAADypwAADVkAABPQAAAKW2Nocm0AAAAAAAMAAAAAo9cAAFR7AABMzQAAmZoAACZmAAAPXP/bAEMABQMEBAQDBQQEBAUFBQYHDAgHBwcHDwsLCQwRDxISEQ8RERMWHBcTFBoVEREYIRgaHR0fHx8TFyIkIh4kHB4fHv/bAEMBBQUFBwYHDggIDh4UERQeHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHv/CABEIAZABkAMBIgACEQEDEQH/xAAcAAEAAwEBAQEBAAAAAAAAAAAABQYHBAgDAgH/xAAbAQEAAgMBAQAAAAAAAAAAAAAABAUCAwYHAf/aAAwDAQACEAMQAAAB2UAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADKdR8/QeoWqmW2D1db+8e1TvRf0qVtvvJwzjIKdgdcrF3MofWOnojun7jY65OVrZFn9NxP65xfRSFmrjzfiwbePP1d2XS5kDrOm00227oFbkoRrmbJa/OW02XD2QTuYAAAAAAAAqOPW+oUvpi21K24SakNNhcNf8AOvoK04XoE/lEDPQOuXhwoPWnTzdP3CcrVlrWyKGqbe9UyDX7jzrh8/egfP0e3Cv65balbd0CpDTPW6o2TbB2sX3lAAAAAAADn6KVrl5V8ih9aW2pW3bX1IabBreSWiRUbOLvzFAz0Drl4cKD1p083T9wnK1Za1sii147rNfvn9Lzy3h8/egfP0Dqwr+uW2pW3dAqQ0z2h13Zp3K9AteEAAAAAAAYxreTwumqq1K7sKrbPzP7YWbLU1Tar+rQ+tY7Khb7nzNAz0V9+YMtSl9NqvRYvsx5K1okLnGqti6HzbqUlkGsWfCfDz/6EyWPdVVakHp6rbPzP7YWbLU1TeDWs0/sml2Nw91pwofcQAAAAAKHllhr1H6iGi0W2pW3dX1IabACxbb5x32z4mRgZ6Bmc3hwoPWnTzdP3CcrVlrWyKGqa0zM7Rvq9Z8/egfP0mlCv65balbd0CpDTPAv+oYZudv56EznAAAAAEbJZ5qn5p/Ch9WP3pu2Dl9ts0nJpcZam1y8sTsFHuGm5lN7YW6QM9A3Hm+HCg9adPN0/cJytWWtbIoapqz1jRt9Ze/P3oHz9JpAr+uW2pW3dAqQ0zwJvdMp1a38+CZzYAAAADCtdwmu7L+Ct7O0bPSrrc+bBKowKTk3obz9Vd78hB6jePhVLXc+bYcKb0l083T9wnK1Za1siidwkcG68kvb+ecPn70D5+jXQV/XLbUrbugVIaZ7o79Zk03XKFz5sH3AAAAADgiLMwk1lZmOz4/Y2Qw+/AEDPMdtZWZhIg5ToZ6KyszDfWf3YxB81lfcYmWMtAZa/wAVyzMN9ZWZjurPZNPuNa7Jkfz+myIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB//8QAKBAAAAQFBAEFAQEAAAAAAAAAAwQFBgABAhA1ExUgNBQREiEwQBaQ/9oACAEBAAEFAv8AY91nKpn9caEcQSabrjQXNjhDhV0iB8F+c6UjXGjXGjXGgsMN5DkFEpWNceCiufL1JCsCflY/0dcaNcaNcaNcaHOKJSoa40FlU+XmjrQR2f4xa6QgjIsxzEI2Ls1TGsm8HDh7luy5s1YKuoMRGOyPEoUOhwdORtKc6Zt8/wCcT/E6zGim2RsXZqGNFS4OHD3LdlzZq7OFnSchQ6HB05G7TF01T8TrMaylZGxdgq5hilhaRgLuHD3LdlzZq7Sl6qsKHQ4OnI3bdM6ln8JkWQBcWuYglkbF3aJjUIXcOHuW7LmzV2eVnQDCh0ODpyN2cVnqfhdxjTI3RsXdsGNBUu4cPct2XNmrIqOKcrDopDohQ6HB05GyQlDn6y4IZcH8LmMeQqXRsXeidVNRIaRgpZw4e5bsubNWTVc2TmnnQTwEKHQ4OnI2TlM2SmlqAJ8L8B4eRYpv6jG/qMb+oxv6jCaqnBiO/qMb+oxv6jG/qMNtSEPUWVxqy6dv6jG/qMb+owCuqFQy2rnCqlv6jG/qMb+owE4T0hC4tA4BuuYZXf1GN/UY39Rjf1GF1VOFDm/qMb+oxv6jFLgUJTImQzZX73gZ9hbgjYvg3TPjKlnDh7luy5s1wZxn1oUOhwdOR4M81Okf73CZ8lU4I2L4Sn6TTTEjRGHDh7luy5s1wa9ftWFDocHTkeCDV7Ff7lMxIqRn8z4I2L4s4z6hw4cPct2XNmuDYp9ywodDg6cjwQqfcrfc8jPoHammdVVLZA9v8yWgqigly/8AMlo/mS0LRHwDdkMx4ynDhw9y3Zc2a4M0v8qHQ4OnI8GgWnWc+5bMeSpWbJfXVOLvL6hG6MY8pOcOHuW7LmzVyRYU2YJF6CpZQ6HB05G5cEQcZLJ0kSf2rRjxk27RL6ZDiaCpHLi0TDEszTHy4cPct2XNmrJ6UbOVJieAQBhQ6HB05GxBONnKkhLBT6PuOlADgexJkbEmRsSZAIdAIXIdIIDjbEmRsSZBVKJFhjAIZgHYkyNiTI2JMilETaajSURMj7GmQAmkQZ3EopED2JMjYkyNiTI2JMg2lkjQmxJkApaeFOXx/q5//8QAPhEAAQICAwoKCQUBAAAAAAAAAQIDAAQFEBEGEhMUMTRBUXGxFSEyM0JTcpGS4iAiMGGBssHC0RYjYnChUv/aAAgBAwEBPwH+5rl5TCPqdVkTvMUkhOAyaU/MIUyhQsIiclzLPqaOiqRzpvaN8YNOqHG03p4oo5CTKNcXRG6KQoSXm08QvVa4eaUy4W15RFyiQW3LdYjBp1Q8hOONcWhX0hcu04LFpBinaETKjDs8nSNXsqBlcXkk25VccUnm/wAU/MKrqpW8eS+NP0qkM6b7Q31OckxRuZtdkbqrpUgTxs1CLk+bc2ip7PGtivtqpNIVJug6j7GRlsZmENa4AsFgik83+KfmFVOSuMSahpHH3VSGdN9ob6nOSYo3M2uyN0TMy1LNlx02CJ+bM3MKeOmLk+bc2ip7PGtivtquipRCGjLNn1jl93sbm2Hr9T7aQbOLjNn0MYWd6seLyxSDk2WfWbGVPS94/jGFnerHi8sYWc6oeLyxOy6pZ9TahZElbjDdmsb4ws51Y8Xlhbs5en9seLyxIOzYlW71sWWDpe7sw+mYmEXjjKSO15YpSi3ZJV8oeqffb+IuZW+lteCSD8bPoYws71Y8Xlh1ybxpv9sW2K6Wz+MYWd6seLyxSVEuzovg0lKtd95YWhSFFKso9hQ0ri0mhOk8ffVSeb/FPzCu6uVsUh8bIkM6b7Q31OckxRuZtdkbqqaYD0k4Do4+6Lk+bc2ip7PGtivtrunYDc5fDpD06MlcamkN6Kp2kpeSswxyxO09JOtXqVaRo94j9RyH/X+GGXkPthxGQxS8rjMotGnKPhEhnTfaG+pzkmKNzNrsjdVTLwZknCdVnfFyfNubRU9njWxX213UPBc2EjQPTuUleW+dn5qugmsPOkDIniruWmr+XLJ6P1qelcVpUI0Xw31OckxRuZtdkboefbYTfuGwRTdL48u8RyB/sXJ825tFT2eNbFfbVSdMsySSAbV6vzDrinVla8p9NqdmGk3rayBtjhKc61XeYJJNprZfdZNraiNkcJTnWq7zC5l1xYWpRJEcJTnWq7zHCU31qu8wmkJpIvQ4bNsOOrdNqzbUzNPM82ojZHCU51qu8wZ+aJvsIbdsKn5pYsU4e8/2d//EACwRAAEDAgMHBAIDAAAAAAAAAAEAAgMEEBESMRMhMjNRoeEgMEGBYXAUIiP/2gAIAQIBAT8B/c1bJg3KoScyzFRuztDrS8BWJQJxUxO0KiqXxn8Jrg4YhVx3hYlNJ2Z+kHuGhVLU5/6u19qqfnkUPFahfi0ttLwGw1U3MNqM/wCSr9RZvLd9Wh5g9mV+RhdaHitTPySC0vAbDVTcwpjC84BRR7NuVV+os3lu+rUkBJzn2axzcMpKyx9e3lRBmbcVlj69vKwj69vKjeHtBCk4CssfXt5QbHjr28qUMznemlrTiHdvKhnEirQ3EYlZY+vbymhmQ71lj69vKhnbH87kDjvHsVD88hNoeK9C/cWqXgNhqpuYbUzssgVfqLN5bvq9E7GPD1zPyMJtHC6ThUdLI12JX8OVOaWnAqnfkkBUvAbDVTcw2p25pAq/UWby3fV6JuEePrrn6NtSMyx3rmYOzWa/PBj+LDVTcwprS44BU1PshidVX6izeW76tDTukP4QAaMB6zGx28hbGPp6HNDtVsY+iDGgYALYx9FsY+iMTD8INA0s5jXahbGPotkzohEwfH7O/8QAOhAAAQICBAkKBgMBAQAAAAAAAQIDABEEIDKSEBIhIjEzcnOxBRNAQVFScYKhwSMwQmFigTSQkaLR/9oACAEBAAY/Av7jww2sgNjLI9ca1y9HKRLiiQ2JZY1rl6EO84s4pnahLibKhMVaQQSDL3jWuXo1rl6Na5ehv4q7Q+qHglxYGTr+0a5y9Ak+Vjuryxiat4fT2+GF/dq4RrXL0a1y9GtcvRrXL0JCXFD4SdBjXOXozKQojsVlEc04Oae7OpXRFOKspEzDjytK1Twcp7sYebJzmji/qrSNn3qN7Yh7y8MIcQopUkzBhLv1jIsffBSN0rhVTuk4ZgyIjPPxm8ivv9+h80DnOmX6w8p7sYeaJyOiX7q0jZ96je2Ie8vCo6z1LRP/ADBSN0rhVTuk1AjqcSR0Pmwc1oYv7w8p7sYUuJ0pMxCHU6FpnUpGz71G9sQ95eFSfY2cFI3SuFVO6TUYl1TPp0Jx5WhCZwpxWlRmcPKe7FRTBOVpXoalI2feo3tiHvLwqOUpX15qfDBSN0rhVTuk1HKWoZAMVPQksA5XTl8BU5T3YqISTmu5hqUjZ96je2Ie8vDCHHQUMdve8ICEDFSkSAwUjdK4VU7pOEGRQz1r/wDISy0mSE6OhLAst5gqcp7sVApOQjKIafH1pnhpGz71G9sQ95eGEJxuca7io51k+KTpGCkbpXCqndJw/DXjN9xWiMZvNWLSD1dBdfP0JnFtu5Ftu5Ftu5Ftu5FNdWpOM0iac2LbdyLbdyLbdyLbdyHUvkc4gzyCWTC883LHSMkW27kW27kW27kISVtyKgLEOMtKRiJlKaftFtu5Ftu5Ftu5CSvEUmeUYumEPNmaVCYh1xOlKCR/kW27kW27kW27kW27kBtlSMXmwcqYtt3Itt3Itt3IGc2fJCH29CvToDdGGlwzPgKvKe7FVsmyvMVhpGz71G9sQ95eFV2iqNnOTFI3SuFVO6TVXRToWMZPj0BwiyjMFXlPdirMQ0/3k5fHBSNn3qN7Yh7y8KrY7wIikbpXCqndJq0c/lL57r3YnJ4xM1eU92KztFJs56cFI2feo3tiHvLwqtfYE+kUjdK4VU7pNWjD85/PaooOnPVhCRpOQQMakOT69EfyHfSKQyl5ZDyZH7R/Id9I/kO+kc0CVIKZpJwtOE5pOKrwOCkbPvUb2xD3l4VXqUR+CYpG6Vwqp3SaqqQbLYl+z895wHNnip8BhQSM1vPNZL4GVo+hqMuzyykrxikbPvUb2xD3l4VEstCZPpCGG9CR/sUjdK4VU7pNRLTScZStEJZTlOlR7T855yeWUk+JqKfIyuq9BWcZVoWmUKQrSkyOF6ik/mmKRs+9RvbEPeXhhGIjFb76tEYjeVRtLOk4KRulcKqd0nCOabOL3zojJnum0v54Q+nGSDOU41BvGNQbxjUG8YS02JJSJAV1OuMzUrKc4xqDeMag3jAeZaKVjrxjCmXRNCtMag3jGoN4xqDeMBQYMx+RgvPNYyzpOMY1H/RibdFbn2kTqKQqyoSMag3jGoN4xqDeMag3jHOPNYypStRqP+jE00Vuf3yxk/tc/8QAKhAAAQIDBwQCAwEAAAAAAAAAAQARIFHwECExYaGx8UGBkcFAcTDR4ZD/2gAIAQEAAT8h/wBj8XXvi9fsy5Yne0QndiuWIKm2wle3RHdcM2RhDGAsQWOBcsXLFyxFBLc5NdD4oMDCgK8A70UBfG4n2rvGDkz5TWmQUEghoj7Lli5YuWLliBw3GKJpvDyUIkO673lAw3Rd4P18Q47FmyCxoAfeypZ2s7x01CsodG2QVSa0uzazqIMQURrC4nSxQJoa9naMnEOCDeF1y/QvhnVh4defXm2pZ24YvHrx7h0bZBVJrS7MD5Ok5l/bKBNDXs4Cut5fsXjb4bq+8svNtSztPqw/3BEfcQe8GjbIKpNaXZgOywc6WUCaGvZwZwB5fCNBeD7I/rmmzNtSzgvYrp5B7g0bZBVJrS7MAS2PisT52soE0NezgLYjzmevwrvLcjdoKlnBcgA7nTWDRtkFUmtLs2g2suSuOT9kK+wDACygTQ17O1gom+GkxTRisHwikTj/AGapjJMZJjJVLNMZJjJMZJ14sEkV00Asj1t0bYmMkxkmMkJweRaXZTGSYyQsELquwyPRCmRxjI2UCZMZJjJMZJjJV7NMZJjJB4J1L7skn+fZn7D4PUJAEz0XEVxFcRXEUVVCbEMb1xFcRXEVxFEiQAxBf20vYBkiHGIXEVxFcRT6Qi5NAvLgCTeBXEVxFcRRuxQbEM+1foGE1aHuHUEuIriK4iuIoJwVzTeVxFcRXEUSiADeGXo6dxeJuo+A8uhnfaGpZwuEbXMNWt0bZBVJrS7MJ5aLI4+vKoE0NezhMf4gGOm3wHCubw46vDUs4TAIxBcFCdiD6hcdbNG2QVSa0uzCYcbi/h/SoE0NezhKCOOtd+cxzebvXDVESEcm8w1LOLG2LsG4+vNmjbIKpNaXZhOUMDXkqBNDXs4SDOgeF/58Qo2MhcPdomXIxMo1otwBjri0GU0YgP8ARcWnFo3hyxoztuaNAFmjbIKpNaXZhPhJnNT6VAmhr2cIHsGNHR/z3uAaQtv1A9wYaxXpF98G7QOo7xy4rRtkFUmtLswPt3eegdSUH7DPN1KoE0NezgIkKYAv7TDD+ZjWbcQSwJ4N3iCS5B90CpjPuFrOMrjQ+lo2yCqTWl2bTYU2Im7JppPTCkZWUCaGvZ2hR8xuR7py3TeDQSH5yj2ABi/sqK9qivaor2vrM8hG/NboA5VFe1RXtO+hZwmiMYHZ1RXtUV7VFe0MEI45kVaxuDAMgLrqzQeJHBw1QutAG5Apgqivaor2qK9qivaASgCJcLghM1ZoIZnUfZAAYAAOg/1c/9oADAMBAAIAAwAAABDzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzox1Tzs8pyj849m1PzzzzzzzzxT397yr+v39z3+j/rzzzzzzzypz3+/yr+v3hz3+j/8A88888888xDWDQfpBSCQzpDAD298888888+/9/wD+av6/f/vf6P8A9zzzzzzzz/bLLfyr+v3+z3+j/wDU888888x/W88a/C/r9/F9/o/td8888889/wDvPLf/AH+707x//wBe8888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888//EACgRAQABAgQGAgMBAQAAAAAAAAERACExQVFxEGGRobHwIIEwwfFw0f/aAAgBAwEBPxD/AGYCUhB6ZE9SjtBtUJCw2wrMEp9ZP2Q8CIvuK5LpWBmDlyp6Rs8lP08kEX5hid9KHSEh+qi4P/BrkulHCGzV6U0QagTexiScE5OF8He34bQZn7w7RWNwiAljDvg6njh6XRw7J8V6HRwbMSjvh4CveaPw6woZuhJ3/CxuYnbF7TQEFisbhEXGT8upJw9Lo4dk+K9DoqFCd+QZvKgwiVjQLB0717zR+HU+CzDJo83CNJnL8NlVQkgt2MS22Nf29YyEyE6VoYtsbY3wr+3qqQ9XWc8HAZIbl4Js4wUixltExLDOGN4a/v639huehCmyVCkIYlG0u9KFrJfbK8ygQRWIscli7S2GzUArJMuFnSbtX9vVzuCCUOe+CLZM8or+3q00BK+5Cd5HnFGlCQmifgmggJb3diD64Y3GIFY3blztPSvS6OHZPivQ6OAcXEN7vEn3XvNH49BDwF3JPAfOZS5l2LvYigisAt0QLhE4b1M8suLAZ7DXOenKnFkpGosJB9l3fD7r0ujh2T4r0OjhmlIb2fua95o/HpOsId1XwnzwFy+f078JqZH6x7qfXGSl1Jtd5nrwicxZshOmH1w7J8V6HRSEZZrHu1KVnB1Wr+j/ALb3mj8OjqZQy56Dli96WKUleb8+QrhB0GvYv3TpJXHiqctpSW+q9i/dRRyhVUi5DjZr2L90qQ+lzoGOCAFAGRepY1qq+eAaGuMknpXsX7oSoUwyknGL5wTU4M9M6x/03//EACcRAAECBQQCAgMBAAAAAAAAAAEAERAxYaGxIUFRwXGRMIEgcNHh/9oACAECAQE/EP3M1hM4CMn2OCgAuCghNxCzOFWTZqgtXc5WsC/BAMoowb4KrKYd+yMuQIh/UPPxPrSGixnBg6O3cLM4hKVycwMQfkqzMLjtAyCjkfDQhEuXKxnBg+jI6e4WZxCUrk5QKNygBDZWZhcdoCIdBKvwshwfXQP2FVoH1sjtQ1VWitQYp03V4OFVoYNaC3zdztXynsgUC2B1FG7KJfh9P2FVom+zjbzVVaCrEzwb/UARIPwNhIaD6hjODF8nyrM4hKVycwKWNy3tWZhcdolebH8+fYPbJJqGx35BVC4RnOC4YkftWZxCUrk5gYMcv6VmYXHaJiFufzlvn+QZyZnWLKG+RB+3usISlcnKZy5XIC1FZmFx2gNEhuX8QxIH5nGRPhUPoIAAMIhmEHyqH0ERAAFUPoKh9BFnIv4QtgaElj5VD6CAwwFvCJOB9D9nf//EACoQAQABAgMHBQADAQAAAAAAAAERACEQMVEgQWFxgZHwMEChscGQ0eHx/9oACAEBAAE/EP5Xpwn0JqampwnampqanCfbhg+XBGphvH2V5X+0pCRGvfJbdK8r/aZiy8hQqlyS1A31ggE+9ljaSwaKUzeX3ryv9ryv9pelGjfI8aOmCJ5ogxSsuN4L90uCrmFpLZ0SkqF8eDem5wzMUfJohHOHdT5X915X+15X+15X+0gqsCTvQNCpA6n9tLMi8AaJ+Ep7MN+1puTxX0n2hk2C3Ar9U/KzJulMdC2yqckODnK79m0ZuePldOxzDUBeBZJRgP7sEJQ0RE58MYztwFe5DkMkTJpYBQbtCZHEGeI+zGAkIZ5j9NoqFwJfl/wXXaZuePldOzzWL3gtEh7LGM+hBYpMNQ/Z39mEARZl/oh02lW+KQckE+qB5AV0THTLZZuePldOzzaEynUj9xjPoQMEr+UP7qMvYjSJk3wWOtJVehmUV+9tXKwIre90Bhss3PHyunZ5r1aAmazyGzFGfQgT3KQz0WcgDq6eyTJxw3tLv6Aqk6KC2ld9gddlm54+V07HMEHhkWho78huloXtB4EQBjGduCAhduE3yf0G+jJEl+Vd6t19k1UITKS77k6FcR2riO1cR2oMEPKrxHauI7VxHakYAhmDI9yo2IGGhZ0ZMbo6Nkzdq4jtXEdqzC5PDRWEeRXxHauI7VCgwUDuX14U9CSLJoz6cnGM6jtXEdq4jtXEdqCwDyKcR2riO1EMzcqnyfE+aWsESL+pqbk+PYwZIoaFnVg2UUUUUT1oCXSGeRnsooootewTAoyNA34mJ60FkpXHOy04ooovaQCbCBo9qMBSkrnddhFFFMOCDLcBkxk0MM/hHc8RkeJSeJrICBJvubKKKKLjVIjcm7y2EUURr0YSE3JLk1vkFW52XiPsLOcXOkdUekVu5pmbRndAuU7DNzx8rp2uckWQ5ySCcJlgjPowI/WEvBjnd7Ae+Um0WrrJ6SqfBgZiZNOCWgOgexxZuePldO1zTACpvJj5HbAM+jA9ojcbwq+/XFsGCc7T3FPQUo71z9NUrMUFztJyZYmbnj5XTtcy8lS0APtMAz6MBETKcgr69cLjUDlYXmy6YtPPBmjAd6cXphGQvFsprwL8qLBZ6E3gZ3314F+V4F+UJOhIAyBi1kfjE71bbswvJR6UXMGbnj5XTtc5JABhmqQ9sMZ9GBrs2FZtR0+Q9Zo76cbsgnOF64oyLJFsg9w9NrI2Nhe0uwxGdBZD6hmnOJ64M3PHyunZ5ocugWea3B/lFzJiEKXXisuEZ9CAv/yvl0DNdxSxAkAif4NxwD1hmTetkI5SvSmVxsXKml7w2gEkpN0IHow9KXcGEyRH6xtLBGO8gT5dMGbnj5XTsc2Q5eiNd58D4pxZlIk04DcMYztwAzNBE+ss+RLTFLZDKaP+jv8AXizfg2pLImy99iNGjDnNIrBldz237QpDUgYxjRiicMqIiIsNmnPHDUAjmXzDYjRowPDvPCMlLYqxIgFhjIKcmbm9LkBIEdRlDQAAAFgMbw2yiEiScHZjRo0Yfph0cQPGgMy86yNuRJnzoaVoAgP5XP/Z',
};

export const MARKETPLACE_URL = {
    // subscription marketplace url
    cn: 'https://cn.marketplace.ability.abb',
    eu: 'https://eu.marketplace.ability.abb',
    us: 'https://us.marketplace.ability.abb',
};

/* Interval to auto refresh, Below value are mentioned in milliseconds  */
export const LoadInDefinedIntervals = {
    sec15: 30 * 1000, // 30 Sec
    sec900: 900 * 1000, // 15 Min
    instantaneousDropDown: 15 * 1000, // 15 Sec
    sec60: 60 * 1000,
    sec30: 30 * 1000, // 30 sec
};

/* constants for all assets header */
export const allAssetsActiveInactive = {
    active: 'Active',
    inActive: 'Inactive'
};


export const ContactSupportErrorMessage = {
    supportTypeErrorMsg: 'Type is required',
    messageErrorMsg: 'Message is required',
    messageLengthErrorMsg: 'Message length has to be less than 5000 characters',
    messageInvalidErrorMsg: 'Message contains invalid characters',
};

export const ChartDarkTheme = {
  colors: ['#d35400', '#2980b9', '#2ecc71', '#f1c40f', '#2c3e50', '#7f8c8d'],
  chart: {
    backgroundColor: '#161C20',
    style: {
      color: '#666666',
    },
  },
  title: {
    align: 'left',
    style: {
      fontWeight: 'bold',
    },
  },
  subtitle: {
    align: 'left',
  },
  xAxis: {
    labels: {
        style: {
            color: '#fff'
        }
    },
  },
  yAxis: {
    labels: {
        style: {
            color: '#fff'
        }
    },
  },
  legend: {
    align: 'right',
    verticalAlign: 'top',
    itemStyle: {
      color: '#424242',
    },
  },

  plotOptions: {
    line: {
      marker: {
        enabled: false,
      },
    },
    spline: {
      marker: {
        enabled: false,
      },
    },
    area: {
      marker: {
        enabled: false,
      },
    },
    areaspline: {
      marker: {
        enabled: false,
      },
    },
    arearange: {
      marker: {
        enabled: false,
      },
    },
    bubble: {
      maxSize: '10%',
    },
  },
};

export const AutoSignOutTimeout = {
   timeOut: 3600
};

export const GuestAvailablePath = ['/', '/profile-settings', '/notification-settings'];

export const ErrorObjectMrc = {name: 'No data', description: 'Data is not available'};

export const batteryHeightCalculation = {
    staticHeight: 172
}
export const multiPeakMonitorColorContractualPower = ['#868686', '#868686', '#868686', '#868686', '#868686'];
export const multiPeakMonitorColorLineChart = ['#4C85FF', '#E64997', '#D6C918', '#F57C64', '#75BA70'];

export const HARD_CODE_HIERARCHY_SITE_ID = '99900000-1230-0000-1230-000000000123';

export const multiSelectReloadTime = 1900;

// Date format for Zoom navigation
export const dateFormat = 'yyyy-MM-dd';
export const momentDateFormat = 'YYYY-MM-DD';

export const mainsColorCode = ['#7ED6C6', '#3DA190', '#195C50', '#D7F7F3', '#092923'];
export const generatorsColorCode = ['#290700', '#F57C64', '#FFCEC4', '#D93616', '#751A08'];

export const HEALTH_TYPE_MAP = {
    'VeryGood': '#0CA919',
    'Normal': '#2E92FA',
    'Good': '#98D694',
    'Medium': '#F7C530',
    'Moderate': '#FF7300',
    'Critical': '#F03040',
    'Fair': '#F7C530',
    'Poor': '#FF7300',
    'VeryPoor': '#F03040',
};


export const maintainanceColumn ={
    asset : 'asset',
    assetName : 'assetName',
    userData  : 'userData',
    userName : 'userName',
    status : 'status',
    maintenanceStatus : 'maintenanceStatus'
};

export const SEVERITY_COLOR_MAPPING = {
  information: {icon: 'info', color: '#4EC558'},
  maintenanceRequired: {icon: 'build', color: '#4C85FF'},
  outOfSpecification: {icon: 'error', color: '#ffd800'},
  checkFunction: {icon: 'error', color: '#ff7300'},
  failure: {icon: 'warning', color: '#f02f3f'},
}

export type SeverityColorMappingKey = 'information' |'maintenanceRequired' |'outOfSpecification' |'checkFunction' |'failure';
export type SeverityMaintenanceMappingKey = 'VeryPoor' |'Poor' |'Fair' |'Good' |'VeryGood';


export const zoomchartHeight = {
    basicLineChart : 526,
    additionalDataLineChart : 500
}
export const reportTypeDownload = {
    All: 'EXCEL',
    TotalActiveEnergy: 'EXCEL',
    TotalActivePower: 'EXCEL',
    SensorDataAnalog: 'EXCEL',
    TotalApparentEnergy: 'EXCEL',
    TotalApparentPower: 'EXCEL',
    ArcGuard: 'EXCEL',
    CurrentSensingLogs: 'EXCEL',
    MeteringDataMonitoring: 'EXCEL',
    Currents: 'EXCEL',
    TotalPowerFactor: 'EXCEL',
    DianaAudit: 'PDF',
    DianaSummary: 'PDF',
    PueTrend: 'EXCEL',
    SensorDataPulses: 'EXCEL',
    TotalReactiveEnergy: 'EXCEL',
    TotalReactivePower: 'EXCEL',
    THD: 'EXCEL',
    TransferTime: 'EXCEL',
    UPSEvents: 'PDF',
    IUPSGuardAlarms: 'PDF',
    IUPSGuardSummary: 'PDF'
}

export const eventBarChartColorForSeverity = {
    checkFunctionCount: SEVERITY_COLOR_MAPPING.checkFunction.color,
    failureCount: SEVERITY_COLOR_MAPPING.failure.color,
    informationCount: SEVERITY_COLOR_MAPPING.information.color,
    maintenanceCount: SEVERITY_COLOR_MAPPING.maintenanceRequired.color,
    outOfSpecificationCount: SEVERITY_COLOR_MAPPING.outOfSpecification.color
};

